

CREATE TABLE `tst` (
  `id` int(11) NOT NULL,
  `d` int(11) NOT NULL,
  `a` int(11) NOT NULL,
  `c` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


