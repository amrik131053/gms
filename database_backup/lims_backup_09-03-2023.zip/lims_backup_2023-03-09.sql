

CREATE TABLE `gate_entry_qr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index 2` (`reference_no`(700)) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO gate_entry_qr VALUES("1","shivam","0");
INSERT INTO gate_entry_qr VALUES("2","0","0");
INSERT INTO gate_entry_qr VALUES("3","01","0");

