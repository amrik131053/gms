

CREATE TABLE `building_master` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Incharge` bigint(20) DEFAULT NULL,
  `infra_incharge` bigint(20) DEFAULT NULL,
  `electrical_incharge` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Name` (`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO building_master VALUES("1","A","170961","","0","");
INSERT INTO building_master VALUES("2","B","170849","","0","");
INSERT INTO building_master VALUES("3","C","170477","","","");
INSERT INTO building_master VALUES("4","D","121079","","","");
INSERT INTO building_master VALUES("6","E","121079","","","");
INSERT INTO building_master VALUES("7","F","121079","","","");
INSERT INTO building_master VALUES("8","G","170477","","","");
INSERT INTO building_master VALUES("9","G1","170477","","","");
INSERT INTO building_master VALUES("10","G2","170477","","","");
INSERT INTO building_master VALUES("11","H","170849","","","");
INSERT INTO building_master VALUES("12","I","","","","");
INSERT INTO building_master VALUES("13","J","170849","","","");
INSERT INTO building_master VALUES("14","K","171091","","0","");
INSERT INTO building_master VALUES("15","L","171091","","","");
INSERT INTO building_master VALUES("16","M","171091","","","");
INSERT INTO building_master VALUES("17","N","121079","","","");
INSERT INTO building_master VALUES("18","A1","171308","","","");
INSERT INTO building_master VALUES("20","Aravali Hostel","0","","170129","1");
INSERT INTO building_master VALUES("21","Shivalik Hostel","171307","","170129","1");
INSERT INTO building_master VALUES("22","Himalaya  Hostel","171307","","170129","1");
INSERT INTO building_master VALUES("23","Neelgiri  Hostel A","171307","","170129","1");
INSERT INTO building_master VALUES("24","Kalpna Chawla  Hostel","171307","","170129","1");
INSERT INTO building_master VALUES("25","International  Hostel-1","171307","","170129","1");
INSERT INTO building_master VALUES("26","Staff Quarters","","","170129","");
INSERT INTO building_master VALUES("27","International Hostel-2","171307","","0","1");
INSERT INTO building_master VALUES("28","Store","170477","","","");
INSERT INTO building_master VALUES("29","Auditorium","170849","","","");
INSERT INTO building_master VALUES("30","Shopping complex","","","0","");
INSERT INTO building_master VALUES("31","Bru Cafe","","","0","");
INSERT INTO building_master VALUES("32","Central Canteen","","","0","");
INSERT INTO building_master VALUES("33","Shopping complex 2","","","0","");
INSERT INTO building_master VALUES("34","NeelGiri Canteen","0","","0","");
INSERT INTO building_master VALUES("35","D Canteen","","","0","");
INSERT INTO building_master VALUES("36","Staff Quarters N","0","","170129","");
INSERT INTO building_master VALUES("37","VC Residence","","","170129","");
INSERT INTO building_master VALUES("38","Neelgiri  Hostel B","","","","1");

