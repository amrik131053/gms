

CREATE TABLE `category_permissions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) DEFAULT 0,
  `category_type_id` int(10) DEFAULT 0,
  `CategoryCode` int(11) DEFAULT NULL,
  `is_admin` int(10) DEFAULT 0,
  `send_mail` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Index 3` (`category_type_id`,`employee_id`,`CategoryCode`) USING BTREE,
  KEY `FK_category_permissions_master_calegories` (`CategoryCode`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO category_permissions VALUES("2","131053","1","3","0","0");
INSERT INTO category_permissions VALUES("3","171306","1","1","0","0");
INSERT INTO category_permissions VALUES("4","170477","1","1","0","0");
INSERT INTO category_permissions VALUES("5","170849","1","1","0","0");
INSERT INTO category_permissions VALUES("6","121079","1","1","0","0");
INSERT INTO category_permissions VALUES("7","170961","1","1","0","0");
INSERT INTO category_permissions VALUES("8","171308","1","1","0","0");
INSERT INTO category_permissions VALUES("9","171091","1","1","0","0");
INSERT INTO category_permissions VALUES("10","121400","1","1","1","1");
INSERT INTO category_permissions VALUES("11","131053","1","1","1","0");
INSERT INTO category_permissions VALUES("12","171307","1","1","0","0");
INSERT INTO category_permissions VALUES("13","131053","1","2","0","0");
INSERT INTO category_permissions VALUES("16","170129","1","2","1","1");
INSERT INTO category_permissions VALUES("17","170982","1","3","0","0");
INSERT INTO category_permissions VALUES("18","171006","1","3","0","0");
INSERT INTO category_permissions VALUES("19","171017","1","1","0","0");
INSERT INTO category_permissions VALUES("20","170967","1","1","0","0");
INSERT INTO category_permissions VALUES("21","150017","1","1","0","0");
INSERT INTO category_permissions VALUES("22","111642","1","1","0","0");
INSERT INTO category_permissions VALUES("23","306","1","1","0","0");
INSERT INTO category_permissions VALUES("24","170649","1","1","0","0");
INSERT INTO category_permissions VALUES("25","170545","1","1","0","0");
INSERT INTO category_permissions VALUES("26","111557","1","1","0","0");
INSERT INTO category_permissions VALUES("27","111013","1","1","0","0");
INSERT INTO category_permissions VALUES("28","111506","1","1","0","0");
INSERT INTO category_permissions VALUES("29","131045","1","3","0","0");
INSERT INTO category_permissions VALUES("30","170803","1","3","0","0");

