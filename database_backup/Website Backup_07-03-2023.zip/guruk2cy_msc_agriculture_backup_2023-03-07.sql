

CREATE TABLE `academic_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO academic_master VALUES("1","10th","academics","0","1");
INSERT INTO academic_master VALUES("2","12th","academics","0","2");
INSERT INTO academic_master VALUES("3","Graduation","academics","0","4");
INSERT INTO academic_master VALUES("5","Diploma","academics","0","3");
INSERT INTO academic_master VALUES("8","Certificate Course","academics","0","0");



CREATE TABLE `academics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `examination` int(50) NOT NULL,
  `course` int(11) NOT NULL,
  `subjects` varchar(150) NOT NULL,
  `university_board` varchar(150) NOT NULL,
  `yop` date NOT NULL,
  `mode` varchar(50) NOT NULL,
  `userid` int(11) NOT NULL,
  `document` varchar(200) NOT NULL,
  `school_clg` varchar(200) DEFAULT NULL,
  `marks_obtained` int(5) DEFAULT NULL,
  `total_marks` int(5) DEFAULT NULL,
  `cgpa` int(5) DEFAULT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `examination` (`examination`),
  KEY `userid` (`userid`),
  KEY `course` (`course`),
  CONSTRAINT `academics_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `basic_detail` (`id`),
  CONSTRAINT `academics_ibfk_2` FOREIGN KEY (`examination`) REFERENCES `academic_master` (`id`),
  CONSTRAINT `academics_ibfk_3` FOREIGN KEY (`course`) REFERENCES `courses` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4;

INSERT INTO academics VALUES("60","3","365","All General Subjects","Guru Kashi University","2022-08-24","Regular","100152","100152-KzCEbaRdKB9eI2Woi5lGVQU4l-10th(FILEminimizer).jpg","Guru Kashi University","0","0","9","0");
INSERT INTO academics VALUES("62","3","365","Horticulture","Guru kashi university","2022-07-19","Regular","2208005","2208005-cveidHkO4MDo2KW9EFWEmopdS-dgree_compressed_11zon.png","University college of agriculture ","0","0","7","0");
INSERT INTO academics VALUES("63","3","365","Elective subject horticulture","Punjabi University Patiala","2021-07-29","Regular","2208002","2208002-M8EYvfRgmYiejvdUHCWGLWI5c-AdobeScanJun22,2022_1(1).jpg","Baba Farid College","5039","6200","0","81");
INSERT INTO academics VALUES("64","3","365","All agriculture subjects ","Punjabi University","2020-05-01","Regular","2208009","2208009-AMZjzEZtwnFomPlWCzCaieZ0h-amritdegree001.jpg","Baba Farid college","3794","5400","0","70");
INSERT INTO academics VALUES("65","1","361","English Punjabi math science social science Hindi","Cbse","2014-04-01","Regular","2208009","2208009-5PKQvddyBRUt7zYOLQTVwMK1W-AMRIT10.jpg","Also academy muktsar","0","0","8","0");
INSERT INTO academics VALUES("66","1","361","English Punjabi science maths social science Hindi","CBSE","2016-05-28","Regular","2208008","2208008-DWvhEiQDoCRq6abaz7I6syhSK-0755DCCC-35B6-4077-9593-F57E50518F5D.jpeg","Modern secular Public school","0","0","9","0");
INSERT INTO academics VALUES("67","2","364","Physics Chemistry Math Punjabi English EVS Computer","PSEB","2018-05-07","Regular","2208008","2208008-fWkWVss9ClraBrAw0C0DzeOoe-F0E485C4-8C30-416F-BD27-ACC0A5FD6F33.jpeg","Bharatiya model Senior secondary school","293","450","0","65");
INSERT INTO academics VALUES("68","3","365","Horticulture ","Punjabi University Patiala","2022-11-30","Regular","2208008","2208008-gDAgqGf0zoLczyqmyCR8VOZZt-6DC8E913-0703-44E5-8322-6DE48BDB21BD.jpeg","Baba Farid College","604","700","0","86");
INSERT INTO academics VALUES("69","3","365","Agriculture ","Punjab University ","2022-07-16","Regular","2208010","2208010-6FeZbH8ozzXxVU3RLUtz9n5Gj-IMG-20220808-WA0057.jpg","Waheguru college abohar","3549","4200","0","85");
INSERT INTO academics VALUES("70","3","365","all agriculture subjects","punjabi university","2022-06-14","Regular","2208011","2208011-HzDFRZjBO5mqc3v1FNDNl1t7R-1811004pdf_compressed_page-0001_1_11zon.jpg","GSSDGS khalsa college patiala","0","0","7","0");
INSERT INTO academics VALUES("71","1","361","math science english hindi punjabi sst etc","cbse delhi","2010-05-28","Regular","2208012","2208012-Q6TjmngDXl9u7UTSCjVjZwd3w-bd0e8c36-98cf-481e-bd4f-f92895a95db4_1.png","delhi public school bathinda","360","500","0","72");
INSERT INTO academics VALUES("72","2","364","math physics chemistry english ","cbse delhi","2012-05-28","Regular","2208012","2208012-1LAmxpQVaqYPucGR8ApC5eAl3-116b21b9-f4ff-4ace-9a1e-8bdd6f8cdee7_1.png","sant kabir public school bathinda","305","500","0","61");
INSERT INTO academics VALUES("73","2","364","math physics chemistry english ","cbse delhi","2012-05-28","Regular","2208012","2208012-1LAmxpQVaqYPucGR8ApC5eAl3-116b21b9-f4ff-4ace-9a1e-8bdd6f8cdee7_1.png","sant kabir public school bathinda","305","500","0","61");
INSERT INTO academics VALUES("74","3","365","agronomy soil science agro meterology etc","PAU ludhiana","2017-12-28","Regular","2208012","2208012-Aa59nGV3d8NMoG4j06i7MBA7c-48265117-8f34-4594-8b5b-79f2628c1559_1.png","punjab agricultural university ludhiana","0","0","7","0");
INSERT INTO academics VALUES("75","1","361","All General Subjects","abc","2022-09-07","Regular","2208017","2208017-IWLI5KNs1QzV93d8Kaet8soGR-dummy-user.png","abc","150","200","0","75");
INSERT INTO academics VALUES("76","1","361","All General Subjects","abc","2022-09-07","Regular","2208016","2208016-JuW2fOnaM7Fn7QFzNnm2hFlkg-dummy-user.png","abc","200","250","0","80");
INSERT INTO academics VALUES("77","1","361","All General Subjects","abc","2022-09-07","Regular","2208018","2208018-uNcP88BQR5DFmWyyI2cf4eNa3-dummy-user.png","abc","545","650","0","84");



CREATE TABLE `basic_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `fee` int(10) NOT NULL,
  `candidate_name` varchar(150) NOT NULL,
  `father_name` varchar(150) NOT NULL,
  `mother_name` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `marital_status` varchar(150) NOT NULL,
  `gender` varchar(150) NOT NULL,
  `mobile_no` varchar(150) NOT NULL,
  `adhar_no` varchar(200) NOT NULL,
  `pan_no` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `pay` bigint(20) NOT NULL,
  `removed` varchar(50) DEFAULT NULL,
  `removed_reason` varchar(500) DEFAULT NULL,
  `court_law` varchar(50) NOT NULL,
  `court_reason` varchar(500) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `sign` varchar(150) NOT NULL,
  `password` varchar(50) NOT NULL,
  `permanent_address` varchar(200) DEFAULT NULL,
  `correspondence_address` varchar(200) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `submit_date` date NOT NULL,
  `recruitment` int(11) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `lock_status` varchar(50) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `payment_id` varchar(100) DEFAULT NULL,
  `candidate_status` varchar(50) DEFAULT NULL,
  `payment_reference_no` varchar(50) DEFAULT NULL,
  `additional_qualification` varchar(500) DEFAULT NULL,
  `resume` varchar(150) NOT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_basic_detail_recruitment` (`recruitment`),
  CONSTRAINT `FK_basic_detail_recruitment` FOREIGN KEY (`recruitment`) REFERENCES `recruitment` (`r_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2208220 DEFAULT CHARSET=utf8mb4;

INSERT INTO basic_detail VALUES("100152","M.Sc. Agriculture","Fruit Science","1","Shivam Garg","Rajiv Kumar","Veena Rani","1999-05-10","Unmarried","Male","8557830584","477631732874","AAAAA1111A","shivamgarg9784@gmail.com","0","","","","","100152-GEJhuzQvDmp4U0RhxsCgLKHfP-image.png","100152-BUFPiLCh0XsPA4gZ0fnQoTsct-sign.png","123","sardulgarh","sardulgarh","UR","2022-08-27","15","2022-09-03","","","success","15754812507","Completed","202208290127433BoTaszySXGkzrUFNqrUk3mD5","","","");
INSERT INTO basic_detail VALUES("2208001","M.Sc. Agriculture","Fruit Science","2000","Dalip Singh","Gurwinder Singh","","1998-01-28","","","6280931597","","","dalipkhosa98@gmail.com","0","","","","","","","763192","","","","2022-08-29","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208002","M.Sc. Agriculture","Agronomy","2000","Tejinder Singh","Boota singh","Amarjit kaur","1998-12-15","Unmarried","Male","9781438717","783842958276","AAAAA1111A","tejinder09380@gmail.com","0","","","","","2208002-9kjgunBJqPHWR6AXCQpvdOELJ-Image-IMG_20220622_121005(1).jpg","2208002-u9ZtMYux1ZeZMlmV5hzRLQWpj-Sign-IMG_20220831_121234.jpg","626026","Village kalloh Distt mansa punjab ","Village kalloh Distt mansa punjab ","UR","2022-08-29","15","2022-08-31","2022-08-31","","success","15768559367","Completed","20220831052044IsAhtMd60qXkGnm8oKDhFyeWp","","","");
INSERT INTO basic_detail VALUES("2208003","M.Sc. Agriculture","Fruit Science","2000","Karminderjit Singh","Mandeep Singh","Amarjit Kaur","2000-01-16","Unmarried","Male","9988592691","239481252797","AAAAA1111A","kakubhullar12@gmail.com","0","","","","","","","908174","VPO Raunta Teh.Nihal singh wala Dist.Moga","VPO Raunta Teh .Nihal singh wala dist.Moga","UR","2022-08-29","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208004","M.Sc. Agriculture","Fruit Science","2000","Sarbjit Singh","Jaspal Singh","","2000-09-29","","","7707800463","","","sarbjitsingh5976@gmail.com","0","","","","","","","884989","","","","2022-08-30","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208005","M.Sc. Agriculture","Fruit Science","2000","Akashdeep chahal","Prem singh","Rupinder kaur","2000-11-21","Unmarried","Male","8769235135","693820906400","AAAAA1111A","achahal409@gmail.com","0","","","","","2208005-HPSlt9oBURQSALSJT4vCTacgP-Image-pic_11zon.jpg","2208005-jhPM4n8wxGTjKBSnhPH4FNtMT-Sign-F397E1CA-D5BF-4248-B6B6-D9A3EA772894.jpeg","479156","Village 2b badi kotha ,p.o. Hindumalkot , Ganganagar,Rajasthan,335001","Village 2b badi kotha ,p.o. Hindumalkot , Ganganagar,Rajasthan,335001","UR","2022-08-30","15","2022-08-31","2022-08-31","","success","15767333689","Completed","202208310129283WemX8MWhWjEXE9Fd05DFRAPv","","","");
INSERT INTO basic_detail VALUES("2208006","M.Sc. Agriculture","Agronomy","2000","Pargatsingh","Bhola singh","Baljinder kaur","1996-11-14","Unmarried","Male","9781972097","316853049925","AAAAA1111A","pargatsingh0153@gmail.com","0","","","","","","","188901","V.P.O kasam bhatti .Teh jaito.Dist Faridkot","Teh jaito dist faridkot","BC","2022-08-31","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208007","M.Sc. Agriculture","Vegetable Science","2000","Arpana","Paras ram","Sumna devi","2001-09-22","Unmarried","Female","6230950638","624678733854","AAAAA1111A","thakurarpana547@gmail.com","0","","","","","","","122279","Village Gohju, Post office Basnoor, Tehsil Shahpur, Distt.Kangra.","Village Gohju, Post office Basnoor, Tehsil Shahpur, Distt.Kangra.","ST","2022-08-31","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208008","M.Sc. Agriculture","Vegetable Science","2000","Karan Deep Sharma","Pardeep Kumar Sharma","Rani Devi","2000-08-04","Unmarried","Male","8699265238","242758404126","AAAAA1111A","dikhkaran@gmail.com","0","","","","","2208008-X9LO0Vk3l0UUOg9yIVZOpj0eM-Image-E824D737-56ED-48DE-96CC-D1EA9642F7D9.jpeg","2208008-o7nezwI4Y0Aq3q4Xcn7eFJpn3-Sign-D35CBEF3-2BA1-4C7C-B390-7061688B63C3.jpeg","178881","House No. 451 A Dikh, Bathinda, Punjab-151103","House No. 451 A Dikh, Bathinda, Punjab-151103","UR","2022-08-31","15","2022-09-02","2022-09-02","","success","15778736901","Completed","20220902010830gk3DZtik6uxA7m8cvxhCli9cQ","","","");
INSERT INTO basic_detail VALUES("2208009","M.Sc. Agriculture","Agronomy","2000","Amritpal singh","Satpal Singh","Baljinder kaur","1998-02-06","Unmarried","Male","7688000045","398997390623","AAAAA1111A","gamrit3004@gmail.com","0","","","","","2208009-DH0YcgMeH1GIPzdXaHfrWTnvt-Image-PPPP-Copy-Copy.jpg","2208009-dqJG2yiEAsZsm0MRLD1p9a7JS-Sign-000001-Copy.jpg","505340","#538 TILAK NAGAR GALI NUMBER 5 Muktsar Punjab - 152026","#538 TILAK NAGAR GALI NUMBER 5 Muktsar Punjab - 152026","UR","2022-09-01","15","2022-09-09","","","","","Pending","20220906123019GE25EuqYPuS1dzMGD1m4dRNUj","","","");
INSERT INTO basic_detail VALUES("2208010","M.Sc. Agriculture","Agronomy","2000","Karandeep kamboj","Lekh raj kamboj","Parveen lata ","1998-03-07","Unmarried","Male","8284864477","252253958546","AAAAA1111A","kkamboj7300@gmail.com","0","","","","","2208010-BsNWZlkeFNOMe4fiPYzqEETl3-Image-400E511F-5814-470F-AA59-1F3B279F0330.jpeg","2208010-GP8ZZlPxksPjtQCrVJhK7M49t-Sign-68F5B32D-FEEB-4DF4-A9D0-1A5B53835BD9.jpeg","771284","H.no B/540 , Basti Hazoor singh , Fazilka ","H.no B/540 , Basti Hazoor singh , Fazilka ","OBC","2022-09-02","15","2022-09-03","2022-09-03","","success","259 (offline Misc. Slip)","Completed","20220902233452Fhqx0lNVcyIaLwXwbB7CyAxdg","","","");
INSERT INTO basic_detail VALUES("2208011","M.Sc. Agriculture","Agronomy","2000","SIMRANDEEP KAUR","TARLOK SINGH","ANGREJ KAUR","1997-05-08","Unmarried","Female","9915179748","688091263680","AAAAA1111A","simran79748@gmail.com","0","","","","","2208011-a4h1cFGIJrvPuHAJLz4eIiav4-Image-PHOTO-2022-09-05-09-57-23.jpg","2208011-MyljwWtimjiVqMqnJePbkQZwn-Sign-PHOTO-2022-09-05-09-56-16.jpg","254656","Dhaliwal patti, tehsil dhuri, Pednni kalan, Sangrur, Punnewal, Punjab, 148034","Dhaliwal patti, tehsil dhuri, Pednni kalan, Sangrur, Punnewal, Punjab, 148034","UR","2022-09-06","15","2022-09-06","2022-09-06","","success","262 (offline Misc. Slip)","Completed","20220906031851uU1ntnWF3WM6AP6qIcB8JGfiQ","","","");
INSERT INTO basic_detail VALUES("2208012","M.Sc. Agriculture","Agronomy","2000","AKSHDEEP SINGH","HARBANS SINGH","","1994-05-01","","","9988390003","","","akshdeepsingh2772@gmail.com","0","","","","","2208012-Gwhtyoyz0p3JULe54mD4tHvot-Image-akshphoto.jpg","2208012-fHrlRiTVnfybmRaGxRDseYWrY-Sign-akshsign.jpg","223856","","","","2022-09-06","15","2022-09-07","2022-09-06","","success","15806064209","Completed","20220906033209hAgFfEDoiKGeHfST9SqHhxWXN","","","");
INSERT INTO basic_detail VALUES("2208013","M.Sc. Agriculture","Vegetable Science","2000","Khushveer singh","Amrik singh","","2000-12-10","","","9467702780","","","khushveers87@gmail.com","0","","","","","","","958477","","","","2022-09-06","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208014","M.Sc. Agriculture","Vegetable Science","2000","Simranpreet kaur","Harpreet singh","","2000-04-20","","","9779004940","","","simransandhu96533@gmail.com","0","","","","","","","276703","","","","2022-09-06","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208015","M.Sc. Agriculture","Vegetable Science","2000","Nisha kataria","Karampal","","1999-11-17","","","9878833733","","","nkataria709@gmail.com","0","","","","","","","564399","","","","2022-09-06","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208016","M.Sc. Agriculture","Agronomy","2000","ravinder Singh","jagjeet singh","Lovepreet kaur","2000-01-05","Unmarried","Male","9877309023","955476083434","AAAAA1111A","singhravinder8310@gmail.com","0","","","","","","","958018","jai singh wala","lambi","SC","2022-09-06","15","2022-09-09","","","success","265 (offline Misc. Slip)","Completed","","","","");
INSERT INTO basic_detail VALUES("2208017","M.Sc. Agriculture","Vegetable Science","2000","Gurwinder kaur","Gain singh","","1998-01-02","","","9877896272","","","gurwinderkaur6521@gmail.com","0","","","","","","","239498","","","","2022-09-06","15","2022-09-09","","","success","265 (offline Misc. Slip)","Completed","","","","");
INSERT INTO basic_detail VALUES("2208018","M.Sc. Agriculture","Agronomy","2000","harmanjot singh","jaswinder singh","","2000-05-08","","","9041381011","","","harmanjot36304370@gmail.com","0","","","","","","","304235","","","","2022-09-06","15","2022-09-09","","","success","265 (offline Misc. Slip)","Completed","","","","");
INSERT INTO basic_detail VALUES("2208019","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","175909","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208020","M.Sc. Agriculture","6rp0o8DG","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","929101","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208021","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","566569","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208022","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","rloefWjv","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","385069","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208023","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","tHyjc7NW","","","sample@email.tst","0","","","","","","","293750","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208024","A0nn8ij1","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","460919","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208026","M.Sc. Agriculture","../../../../../../../../../../etc/passwd","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","127570","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208027","M.Sc. Agriculture","../../../../../../../../../../windows/win.ini","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","447935","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208028","M.Sc. Agriculture","../JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","293019","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208029","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","288742","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208030","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","791809","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208031","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","391735","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208032","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","912541","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208033","M.Sc. Agriculture","JCfUZQsq&lt;esi:include src=&quot;http://bxss.me/r","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","199518","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208034","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329<esi:include src="http://bxss.me/rpb.png"/>","","","sample@email.tst","0","","","","","","","183730","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208035","M.Sc. Agriculture&lt;esi:include src=&quot;http://","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","778616","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208036","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","../../../../../../../../../../etc/passwd","","","sample@email.tst","0","","","","","","","706840","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208037","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","../../../../../../../../../../windows/win.ini","","","sample@email.tst","0","","","","","","","340068","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208038","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","../987-65-4329","","","sample@email.tst","0","","","","","","","914069","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208039","M.Sc. Agriculture","${9999291+9999629}","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","691182","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208040","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","158730","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208041","../../../../../../../../../../etc/passwd","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","425768","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208042","../../../../../../../../../../windows/win.ini","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","220349","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208043","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","${9999923+9999605}","","","sample@email.tst","0","","","","","","","770084","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208044","../M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","105957","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208045","${9999786+10000411}","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","785939","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208050","M.Sc. Agriculture","&quot;.gethostbyname(lc(&quot;hitro&quot;.&quot;cd","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","596505","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208051","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","121911","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208052","M.Sc. Agriculture","http://some-inexistent-website.acu/some_inexistent","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","493457","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208053","M.Sc. Agriculture","1some_inexistent_file_with_long_name .jpg","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","545752","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208054","M.Sc. Agriculture","Http://bxss.me/t/fit.txt","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","583198","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208055","M.Sc. Agriculture","http://bxss.me/t/fit.txt?.jpg","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","585940","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208056","M.Sc. Agriculture","bxss.me","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","121484","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208057","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","889366","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208058","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","325808","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208059","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","".gethostbyname(lc("hitdr"."fufdzefn3eed2.bxss.me."))."A".chr(67).chr(hex("58")).chr(103).chr(69).chr(117).chr(83)."","","","sample@email.tst","0","","","","","","","290992","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208060","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","416302","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208061","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","636853","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208062","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","557732","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208063","&quot;.gethostbyname(lc(&quot;hitgw&quot;.&quot;nn","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","914568","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208065","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","http://some-inexistent-website.acu/some_inexistent_file_with_long_name?.jpg","","","sample@email.tst","0","","","","","","","602359","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208066","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","1some_inexistent_file_with_long_name .jpg","","","sample@email.tst","0","","","","","","","817209","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208067","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","Http://bxss.me/t/fit.txt","","","sample@email.tst","0","","","","","","","973044","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208068","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","http://bxss.me/t/fit.txt?.jpg","","","sample@email.tst","0","","","","","","","820802","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208069","M.Sc. Agriculture","&quot;+&quot;A&quot;.concat(70-3).concat(22*4).con","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","704503","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208070","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","bxss.me","","","sample@email.tst","0","","","","","","","928398","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208071","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","808832","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208072","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","",""+"A".concat(70-3).concat(22*4).concat(109).concat(89).concat(115).concat(76)+(require"socket"
Socket.gethostbyname("hitkm"+"cwlayncs7644d.bxss.me.")[","","","sample@email.tst","0","","","","","","","624338","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208073","http://some-inexistent-website.acu/some_inexistent","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","822103","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208074","&quot;+&quot;A&quot;.concat(70-3).concat(22*4).con","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","119541","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208075","1some_inexistent_file_with_long_name . Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","368376","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208076","Http://bxss.me/t/fit.txt","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","157022","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208077","M.Sc. Agriculture",";print(md5(31337));","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","746031","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208078","http://bxss.me/t/fit.txt?. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","122902","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208079","bxss.me","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","451526","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208080","M.Sc. Agriculture","&quot;;print(md5(31337));$a=&quot;","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","375340","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208082","M.Sc. Agriculture","${@print(md5(31337))}","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","298995","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208083","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","302283","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208085","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","586752","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208088","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","585489","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208091","M.Sc. Agriculture","post-action.php","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","827658","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208092","M.Sc. Agriculture","post-action.php/.","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","925419","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208093","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","628543","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208094","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","107683","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208095","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","190782","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208096","M.Sc. Agriculture","/xfs.bxss.me","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","897721","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208097","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","170544","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208098","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","",";print(md5(31337));","","","sample@email.tst","0","","","","","","","280028","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208099","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","";print(md5(31337));$a="","","","sample@email.tst","0","","","","","","","656809","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208100","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","post-action.php","","","sample@email.tst","0","","","","","","","106400","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208101","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","${@print(md5(31337))}","","","sample@email.tst","0","","","","","","","518749","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208102","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","post-action.php ","","","sample@email.tst","0","","","","","","","857783","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208103","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","/xfs.bxss.me","","","sample@email.tst","0","","","","","","","818595","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208104","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","post-action.php/.","","","sample@email.tst","0","","","","","","","344896","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208105","/xfs.bxss.me","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","732519","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208107","post-action.php","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","997196","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208108","M.Sc. Agriculture","JCfUZQsq9403131","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","615320","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208109",";print(md5(31337));","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","598378","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208110","post-action.php/.","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","333330","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208111","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","884825","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208112","&quot;;print(md5(31337));$a=&quot;","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","321867","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208113","${@print(md5(31337))}","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","227497","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208116","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst9344308","0","","","","","","","206327","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208121","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-43299536702","","","sample@email.tst","0","","","","","","","214021","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208122","M.Sc. Agriculture9854932","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","474978","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208124","M.Sc. Agriculture","gYw1iHSN","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","825146","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208125","M.Sc. Agriculture","-1 OR 2+674-674-1=0+0+0+1 --","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","365265","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208126","M.Sc. Agriculture","-1 OR 2+96-96-1=0+0+0+1","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","884299","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208127","M.Sc. Agriculture","-1&quot; OR 2+91-91-1=0+0+0+1 --","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","264886","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208128","M.Sc. Agriculture","if(now()=sysdate(),sleep(15),0)","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","259714","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208129","M.Sc. Agriculture","0","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","731406","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208130","M.Sc. Agriculture","0&quot;XOR(if(now()=sysdate(),sleep(15),0))XOR&quo","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","127835","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208131","M.Sc. Agriculture","0&quot;XOR(if(now()=sysdate(),sleep(3),0))XOR&quot","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","324676","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208132","M.Sc. Agriculture","0&quot;XOR(if(now()=sysdate(),sleep(15),0))XOR&quo","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","869501","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208133","M.Sc. Agriculture","0&quot;XOR(if(now()=sysdate(),sleep(0),0))XOR&quot","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","670111","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208134","M.Sc. Agriculture","0&quot;XOR(if(now()=sysdate(),sleep(6),0))XOR&quot","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","336500","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208135","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","607351","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208136","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","814832","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208137","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","840177","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208138","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","989550","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208139","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","401269","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208140","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","851511","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208141","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","377475","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208142","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","133957","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208143","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","927054","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208144","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","488210","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208145","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","938575","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208146","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","169904","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208147","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","833642","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208148","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","634896","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208149","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","215303","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208150","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","262585","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208151","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","118822","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208152","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","806370","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208153","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","369728","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208154","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","823334","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208155","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","758750","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208156","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","718310","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208157","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","868244","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208158","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","686271","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208159","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","766403","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208160","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","671835","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208161","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","552217","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208162","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","658124","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208163","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","858390","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208164","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","856148","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208165","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","306884","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208166","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","593149","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208167","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","720510","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208168","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","943467","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208169","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","427810","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208170","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","756481","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208171","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","769915","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208172","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","439883","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208173","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","252336","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208174","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","784994","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208175","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","842041","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208176","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","421443","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208177","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","107170","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208178","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","157207","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208179","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","152562","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208180","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","798601","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208181","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","0000-00-00","","","987-65-4329","","","sample@email.tst","0","","","","","","","915372","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208182","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","801529","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208183","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","jbuiJUfc","","","sample@email.tst","0","","","","","","","834856","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208184","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","-1 OR 2+835-835-1=0+0+0+1 -- ","","","sample@email.tst","0","","","","","","","831932","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208185","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","-1 OR 2+286-286-1=0+0+0+1","","","sample@email.tst","0","","","","","","","164800","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208186","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","-1" OR 2+227-227-1=0+0+0+1 -- ","","","sample@email.tst","0","","","","","","","906158","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208187","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","if(now()=sysdate(),sleep(15),0)","","","sample@email.tst","0","","","","","","","578435","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208188","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","0","","","sample@email.tst","0","","","","","","","828417","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208189","M.Sc. Agriculture","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","0"XOR(if(now()=sysdate(),sleep(15),0))XOR"Z","","","sample@email.tst","0","","","","","","","318729","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208190","M.Sc. Agriculture","JCfUZQsq","0","","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","928386","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208191","VR38kcsq","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","109708","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208192","-1 OR 2+831-831-1=0+0+0+1 --","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","687420","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208193","-1 OR 2+215-215-1=0+0+0+1","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","851007","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208194","-1&quot; OR 2+251-251-1=0+0+0+1 --","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","749157","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208195","if(now()=sysdate(),sleep(15),0)","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","843494","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208196","0","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","649521","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208197","","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","214318","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208198","@@UjekD","JCfUZQsq","0","JCfUZQsq","JCfUZQsq","","1967-01-01","","","987-65-4329","","","sample@email.tst","0","","","","","","","421461","","","","2022-09-07","15","2022-09-09","","","","","Pending","","","","");
INSERT INTO basic_detail VALUES("2208219","M.Sc. Agriculture","Entomology","2000","Babbu ram","Mithu ram","","2005-07-07","","","8725062838","","","babburm157@gmail.com","0","","","","","","","568899","","","","2022-09-08","15","2022-09-09","","","","","Pending","","","","");



CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(150) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE KEY `Index 2` (`course_name`),
  KEY `Index 3` (`academic_id`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`academic_id`) REFERENCES `academic_master` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=366 DEFAULT CHARSET=utf8mb4;

INSERT INTO courses VALUES("361","Matric","1");
INSERT INTO courses VALUES("363","Medical","2");
INSERT INTO courses VALUES("364","Non-Medical","2");
INSERT INTO courses VALUES("365","Bachelor of Science in Agriculture
","3");



CREATE TABLE `experience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `post_held` varchar(50) NOT NULL,
  `organisation` varchar(150) NOT NULL,
  `doj` date NOT NULL,
  `dol` date NOT NULL,
  `salary` int(11) NOT NULL,
  `reason` varchar(100) NOT NULL DEFAULT '',
  `document` varchar(200) NOT NULL,
  `experience_type` varchar(50) DEFAULT NULL,
  `experience_years` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  CONSTRAINT `experience_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `basic_detail` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




CREATE TABLE `phd` (
  `phd_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `phd_subject` varchar(150) DEFAULT NULL,
  `specialization` varchar(150) DEFAULT NULL,
  `phd_uni` varchar(150) DEFAULT NULL,
  `yoe` date DEFAULT NULL,
  `yoa` date DEFAULT NULL,
  `awarded` varchar(50) DEFAULT NULL,
  `phd_document` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`phd_id`),
  KEY `FK_phd_basic_detail` (`user_id`),
  CONSTRAINT `FK_phd_basic_detail` FOREIGN KEY (`user_id`) REFERENCES `basic_detail` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




CREATE TABLE `recruitment` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_name` varchar(150) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `r_status` varchar(20) DEFAULT NULL,
  `document` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`r_id`),
  UNIQUE KEY `Index 2` (`r_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO recruitment VALUES("15","August 2022","2022-08-29","2022-09-08","Active","PNgELu0gXt4DL7Fonp3MscW7D-M.ScAdvt-25Aug-22.jpg");



CREATE TABLE `tests` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `test_name` varchar(150) DEFAULT NULL,
  `score` varchar(10) DEFAULT NULL,
  `valid_upto` date DEFAULT NULL,
  `test_document` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`test_id`) USING BTREE,
  KEY `FK_phd_basic_detail` (`user_id`) USING BTREE,
  CONSTRAINT `tests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `basic_detail` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;




CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mep` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO users VALUES("3","131053","7410","","Amrik Singh");



CREATE TABLE `vacancy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(500) NOT NULL,
  `post` varchar(200) NOT NULL,
  `fee` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;

INSERT INTO vacancy VALUES("152","Agronomy","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("153","Fruit Science","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("154","Vegetable Science","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("155","Entomology","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("156","Plant Pathology","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("157","Extension Education","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("158","Agricultural Economics","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("159","Soil Science","M.Sc. Agriculture","2000");
INSERT INTO vacancy VALUES("160","Genetics and Plant Breeding","M.Sc. Agriculture","2000");

