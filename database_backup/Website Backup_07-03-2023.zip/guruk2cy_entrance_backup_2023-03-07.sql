

CREATE TABLE `academic_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  `entrance_type` varchar(20) NOT NULL,
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO academic_master VALUES("1","10th","academics","0","","1");
INSERT INTO academic_master VALUES("2","12th","academics","0","","2");
INSERT INTO academic_master VALUES("3","Graduation","academics","0","","4");
INSERT INTO academic_master VALUES("4","Diploma","academics","0","","3");
INSERT INTO academic_master VALUES("5","Post Graduation Diploma","academics","0","phd","5");
INSERT INTO academic_master VALUES("6","Post Graduation","academics","0","phd","6");
INSERT INTO academic_master VALUES("7","Certificate Course","academics","0","","7");



CREATE TABLE `academics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `examination` int(50) NOT NULL,
  `course` int(11) NOT NULL,
  `subjects` varchar(150) NOT NULL,
  `university_board` varchar(150) NOT NULL,
  `yop` date NOT NULL,
  `mode` varchar(50) NOT NULL,
  `userid` int(11) NOT NULL,
  `document` varchar(200) NOT NULL,
  `school_clg` varchar(200) DEFAULT NULL,
  `marks_obtained` int(5) DEFAULT NULL,
  `total_marks` int(5) DEFAULT NULL,
  `cgpa` float DEFAULT NULL,
  `percent` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `examination` (`examination`),
  KEY `userid` (`userid`),
  KEY `course` (`course`),
  CONSTRAINT `academics_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `basic_detail` (`id`),
  CONSTRAINT `academics_ibfk_2` FOREIGN KEY (`examination`) REFERENCES `academic_master` (`id`),
  CONSTRAINT `academics_ibfk_3` FOREIGN KEY (`course`) REFERENCES `courses` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4;

INSERT INTO academics VALUES("6","2","2","Ggh","Hhh","2023-01-12","Regular","2301006","2301006-SqmeEwbl4bnFtZiOseo6id5S6-Screenshot_20230103-182648.jpg","Hhh","110","56","0","196");
INSERT INTO academics VALUES("7","1","1","dsfsf","sfdsf","2023-01-19","Regular","2301006","2301006-vZQZh5gZhJJ4P9NV0ECCxWetz-asads.jpg","sfdsf","22","3333","0","1");
INSERT INTO academics VALUES("8","6","189","Agronomy ","Dr Bhimrao Ambedkar Agra University ","2018-07-06","Regular","2301137","2301137-slucGT3DGnVKOwnx1Q4Wbs2jx-IMG_20201002_080810_007.jpg","Megh Singh degree College ","457","800","0","57");
INSERT INTO academics VALUES("9","6","122","Education","Panjab University Chandigarh","2014-04-01","Regular","2301009","2301009-DdY5NztgT1l2XjFABfIsfEyq4-M.Ed.jpg","MCEG Ghall Kalan Moga","508","650","0","78");
INSERT INTO academics VALUES("10","6","175","PUBLIC ADMINISTRATION","IGNOU","2018-09-20","Distance","2301142","2301142-OcebUitZoiClMeHUa0rcF6ebj-pgmar.jpg","DEGREE COLLEGE PULWAMA","492","800","0","62");
INSERT INTO academics VALUES("12","1","1","COMPULSORY SUBJECT ","PUNJAB SCHOOL EDUCATION BOARD MOHALI","1997-10-06","Regular","2301139","2301139-pMw51UvJacGErPWSqghWRvA2f-10THDEGREE.jpeg","GOVT SEN SEC SCHOOL VPO MEHRAJ RAMPURA PHUL","297","650","0","46");
INSERT INTO academics VALUES("13","2","4","POLITICAL SCIENCE HISTORY PHYSICAL EDUCATION","PUNJAB SCHOOL EDUCATION BOARD MOHALI","1999-03-06","Regular","2301139","2301139-5Z5fFQdTkQrJtxdDyQbX4na08-12TH.jpeg","GOVT SEN SEC SCHOOL VPO MEHRAJ RAMPURA PHUL","244","450","0","54");
INSERT INTO academics VALUES("14","3","301","HISTORY POLITICAL SCIENCE PUNJABI LITRATURE","PUNJABI UNIVERSITY PATIALA","2002-02-09","Regular","2301139","2301139-7NaBWmETsWBaH1AYhW5Ngn35E-BADEGREE.jpeg","SROJNI NAIDU COLLEGE RAMPURA PHUL","1282","2400","0","53");
INSERT INTO academics VALUES("15","6","112","COMPUTER GRAPHICS INTERNET PROGRAMMING AND JAVA INTERNET PROGRAMMING AND E COMMERCE LINUX OPERATING SYSTEM SOFWARE LAB  PROJECT REPORT","PUNJAB TECHNICAL UNIVERSITY JALANDHAR","2008-12-02","Distance","2301139","2301139-9aZNNcZj0GKMxpIWjqXtsZZAT-MCADEGREE.jpeg","TARA INFOTECH RAMPURA PHU DISTT  BATHINDA","318","400","0","80");
INSERT INTO academics VALUES("16","1","1","ALL SUBJECT","PSEB MOHALI","1994-03-02","Regular","2301149","2301149-lCC2U11fee7c8bRj2hf9hhp7y-002.jpg","GOVT HIGH SCHOOL SHAKUR FEROZEPUR","321","650","0","49");
INSERT INTO academics VALUES("17","2","4","ENGLISH  PUNJABI   HISTORY  ELECTIVE PUNJABI  ECONOMICS","PSEB MOHALI","1996-03-07","Regular","2301149","2301149-moc6pqwO8J0DNJq1l9DhODoK4-003.jpg","GOVT SEN SEC SCHOOL TALWANDI BHAI","239","450","0","53");
INSERT INTO academics VALUES("18","3","301","ENGLISH POLITICAL SCIENCE ECONOMICS","SAM HIGGINBOTTOM INSTITUTE OF AGRICULTURE TEHHNOLOGY AND SCIENCE","2014-06-28","Distance","2301149","2301149-l5ffmJMMBQ12jKDuJfgANpoku-004.jpg","SAM HIGGINBOTTOM INSTITUTE OF AGRICULTURE TEHHNOLOGY AND SCIENCE","1302","1800","0","72");
INSERT INTO academics VALUES("20","6","135","PUNJABI","LPU JALANDHAR","2023-01-16","Distance","2301149","2301149-GpVLaYLXF2dDAtWtkSW7aFsHR-NNM.jpg","LPU JALANDHAR","0","0","6","0");
INSERT INTO academics VALUES("21","1","1","HINDI ENGLISH MATH SCIENCE SOCIAL STUDIES","CBSE NEW DELHI","2015-05-28","Regular","2301143","2301143-3Sl0MLEgmylQFgLaUzxvcfZ6p-525001.jpg","CRESCENT PUBLIC SCHOOL FATEHABAD","0","0","9","0");
INSERT INTO academics VALUES("27","2","5","ENG ECO HINDI MUSIC BUS ACC ","CBSE NEW DELHI","2017-05-28","Regular","2301143","2301143-8qTYxLeN7VlYDOcCJFJCNI4Oy-525002.jpg","CRESCENT PUBLIC SCHOOL FATEHABAD","385","500","0","77");
INSERT INTO academics VALUES("28","3","237","ECONOMICS COMPULSORY SUBJECTS","AKAL UNIVERSITY","2021-10-28","Regular","2301143","2301143-M5xSCSY3O07jcZWb9bzIQjhBR-BCOMHONS.jpg","AKAL UNIVERSITY CAMPUR","0","0","6","0");
INSERT INTO academics VALUES("29","6","121","ECONOMICS COMPULSORY SUBJECTS","PUNJABI UNIVERSITY PATIALA","2022-09-28","Regular","2301143","2301143-aRCqm78oTEIcU7poEIdmQzgmn-POSTGRADUCATION.jfif","PUNJABI UNIVERSITY CAMPUR","0","0","6","0");
INSERT INTO academics VALUES("30","1","1","punjabi hindi english math science social science","PSEB MOHALI","2005-06-05","Regular","2301151","2301151-82Bk6hYubguhXo24nyWsrsI2z-Screenshot_20230117_175644_SamsungNotes.jpg","Dr chanda singh marwaha govt girls sr sec school kot kapura","369","650","0","57");
INSERT INTO academics VALUES("31","2","4","Arts","PSEB MOHAli","2007-06-06","Regular","2301151","2301151-EaE53bWANcasTmO7DuqkfEErL-Screenshot_20230117_180839_SamsungNotes.jpg","Govt girl sen sec school faridkot","278","450","0","62");
INSERT INTO academics VALUES("32","1","1","ALL SUBJECTS","PSEB","1995-06-19","Regular","2301155","2301155-EOUQaDxXA9C4hiyeH6pzYWBLs-10.jpeg","DAV  GIRLS SCHOOL MUKTSAR","521","650","0","80");
INSERT INTO academics VALUES("33","6","122","EDUCATION TECHNOLOGY LIFE SKILLS EDUCATION INCLUSIVE EDUCATION DISSERTATION","PUNJABI UNIVERSITY PATIALA","2021-08-20","Regular","2301147","2301147-HpavdhUwy3vUI7h2h7SpAqN2j-M.ED.jpeg","GURU TEG BAHADUR COLLEGE OF EDUCATION LEHAL KHURD","0","0","9","0");
INSERT INTO academics VALUES("34","3","239","ASSESMENT OF LEARNING GENDER SCHOOL AND SOCIETY INCLUSIVE SCHOOL UNDERSTADING THE SELF READING AND REFLECTINOG ON TEXTS STRENGTHERING LANGUAGE PROFICI","PUNJABI UNIVERSITY PATIALA","2018-09-21","Regular","2301147","2301147-MHr92fw8bLUrPfGwOJOzGEzTo-WhatsAppImage2023-01-18at16.56.16.jpeg","GURU TEG BAHADUR COLLEGE OF EDUCATION DALELWALA MANSA","1328","1800","0","74");
INSERT INTO academics VALUES("35","2","4","GENERAL PUNJABI GENERAL ENGLISH POLITICAL SCIENCE HISTORY ECONOMICS","PSEB MOHALI","2010-05-31","Regular","2301147","2301147-jB0Logs7ZmjsJ9DOWlzSUZDNA-WhatsAppImage2022-05-09at2.08.21PM(1).jpeg","GOVT GIRLS SEC SCHOOL MANSA","239","450","0","53");
INSERT INTO academics VALUES("37","1","1","PUNJABI ENGLISH HINDI MATH SCIENCE SST","PSEB MOHALI","2008-06-14","Regular","2301147","2301147-WakjS5bNmv1x2pjkpvDGvu7I0-WhatsAppImage2022-05-09at2.08.21PM.jpeg","ADARSH PUBLIC SR SEC SCHOOL RAIPUR MANSA","362","650","0","56");
INSERT INTO academics VALUES("38","2","4","English Punjabi  Elective Punjabi History Philosophy","PSEB","1997-10-07","Regular","2301155","2301155-9eHkwuiTJ4U5X7kl7rE6RxyFb-WhatsAppImage2023-01-18at14.45.17.jpeg","DAV GIRLS SESECSCHOOL MUKTSAR","309","450","0","69");
INSERT INTO academics VALUES("39","3","238","PUNJABI POLITICAL SCIENCE  MUSIC","PUNJAB UNIVERSITY CHD","2000-07-11","Regular","2301155","2301155-vFfM9gdg3MFHf4kkb3MIPULGo-WhatsAppImage2023-01-19at10.45.13AM.jpeg","GURU NANAK COLLAGE  FOR  GIRLS MUKTSAR","1538","2400","0","64");
INSERT INTO academics VALUES("40","6","172","INTERNATIONAL RELATIONS DEMOCRACY AND DEVELOPMENT IN INDIA  POLITICAL THEORY COMPARATIVE POLITICS SOCIAL MOVEMENTS AND STATE POLITICS IN INDIA  MODERN","LOVELY PROFESSIONAL UNIVERSITY CHD","2014-04-16","Regular","2301155","2301155-iQNxy30kQM5LAOC6KWQKT8FJv-WhatsAppImage2023-01-19at10.59.19AM.jpeg","LOVELY PROFESSIONAL UNIVERSITY CHD","0","0","8","0");
INSERT INTO academics VALUES("41","3","301","ENG PBC ECO POL","GURU NAANK DEV UNIVERSITY","1989-07-01","Regular","2301156","2301156-5TjhsConIyVmbA0MrQEMz2Np1-BA-page-001.jpg","KRM DAV COLLEGE NAKODER","378","750","0","50");
INSERT INTO academics VALUES("42","6","172","PAPER","GURU NANAK DEV UNIVERSITY","1991-09-10","Regular","2301156","2301156-IwNXuymgmVavMm0pRGmFb1B9M-MA-page-002.jpg","DOABA COLLEGE JALANDHAR","400","800","0","50");
INSERT INTO academics VALUES("43","1","1","ENG PBI HIN MAT SCI SST PED DRW","PSEB","1985-07-09","Regular","2301156","2301156-SQFja3VDtDZ9kLjc4SNN1byPm-10th-page-001.jpg","GOVT HIGH SCHOOL MOHEM","694","800","0","87");
INSERT INTO academics VALUES("44","6","147","Law subjects","Punjabi University","2014-05-31","Regular","2301152","2301152-6tqKFQIEB4OmbHdoHPk5NdEXk-IMG-20230120-WA0007.jpg","Department of Law","1400","873","0","160");
INSERT INTO academics VALUES("46","6","135","Punjabi","Punjabi University Patiala","2015-04-30","Distance","2301154","2301154-FPk9i0pcEOzs0F6hMr4D6dOd0-cert.jpg","Correspondence","487","798","0","61");
INSERT INTO academics VALUES("47","1","1","Punjabi Hindi English Science Social Studies Mathematics","PSEB Mohali","2005-06-05","Regular","2301150","2301150-OATcNpIBPLiAvyusD3ReOJ33F-ManpreetKaur10th.jpg","Govt Girls M P Sr Sec School Patiala","439","650","0","68");
INSERT INTO academics VALUES("48","2","4","General Punjabi General English Elective Punjabi History Economics","PSEB Mohali","2007-06-06","Regular","2301150","2301150-p7tpgnsP4tRetJ4o1Nebaz8xI-ManpreetKaur12th.jpg","Govt Girls M P Sr Sec School Patiala","356","450","0","79");
INSERT INTO academics VALUES("49","3","237","Economics","Punjabi University Patiala","2010-07-02","Regular","2301150","2301150-fUMPZWhK7fw9v75ai39f9OzTs-BSc6Sem.jpg","Punjabi University Patiala","2935","3900","0","75");
INSERT INTO academics VALUES("50","6","121","Economics","Punjabi University Patiala","2012-08-03","Regular","2301150","2301150-xIf8gabP6el8y7YqE0Z3xH0Fi-MA4Sem.jpg","Punjabi University Patiala","1142","1600","0","71");
INSERT INTO academics VALUES("52","1","1","Telugu Hindi English Science Social Mathematics Social ","Board of Secondary school education ","2014-05-15","Regular","2301161","2301161-ht8W70XAN9RtWhk7xLRjxRZQm-IMG20230123202053_copy_528x705.jpg","BVS High School ","0","0","7","0");
INSERT INTO academics VALUES("55","2","2","Botany Zoology Physics Chemistry ","Board of Intermediate education ","2016-04-19","Regular","2301161","2301161-HbLNzOHNWT1paPCSZOgmDjUnC-IMG20230123202101_copy_540x720.jpg","Sri Chaitanya jr College ","1000","623","0","161");
INSERT INTO academics VALUES("56","3","268","Agriculture","Centurion University of Technology and Management ","2020-04-21","Regular","2301161","2301161-06jj8MTpkx6WmXVd9bTOmiEw8-IMG20221008092237_copy_885x664.jpg","Ms Swaminathan Institute of technology ","0","0","7","0");
INSERT INTO academics VALUES("57","6","189","Seed science and technology ","Sam Higginbottom University of Agriculture Technology and Sciences","2022-08-05","Regular","2301161","2301161-lR00jqJpYSch1Ux2qtuMOra3V-IMG20221008092525_copy_528x704.jpg","Naini Agricultural Institute","0","0","7","0");
INSERT INTO academics VALUES("58","6","135","Punjabi","Punjabi University Patiala","2012-05-31","Regular","2301162","2301162-2taP1JDB35wrR5N4gEFjrJhE6-DMCMAsem4.jpg","Punjabi Department Punjabi University Patiala","1632","2400","0","68");
INSERT INTO academics VALUES("59","6","135","Punjabi","Punjabi University Patiala","2011-05-31","Regular","2301165","2301165-npn92JoNrTgZE9VxbtG3H1HYQ-MASem4P.jpeg","Punjabi University Regional Center Bathinda","1103","1600","0","69");
INSERT INTO academics VALUES("62","6","172","Contemporary politics Thought   Modern Political Analysis  Theory and Practice of Public Administration   Contemporary Western Political System ","PUNJABI UNIVERSITY PATIALA","2002-09-09","Regular","2301171","2301171-CYIWH8x1wX4wHvKElfOeFsJjQ-WhatsAppImage2023-01-27at9.35.11PM.jpeg","GOVERNMENT RANBIR COLLEGE ","480","800","0","60");
INSERT INTO academics VALUES("63","1","1","AS PER SYLLABUS","PSEB MOHALI","2005-11-10","Regular","2301181","2301181-6Ag813evILbxCwnMsAefaGyaB-MATRIC.jpg","GOVT SEN SEC SCHOOL JOGA DISTT MANSA","462","850","0","54");
INSERT INTO academics VALUES("64","2","4","ENGLISH PUNJABI HISTORY POL SCI PHY EDU","PSEB MOHALI","2007-06-06","Regular","2301181","2301181-aZSHZZCs1p23t4wvulHIt5HUo-10+2.jpg","GOVT SEN SEC SCHOOL JOGA DISTT MANSA","298","500","0","60");
INSERT INTO academics VALUES("65","3","353","AS PER SYLLABUS","PUNJABI UNIVERSITY PATIALA","2013-08-01","Regular","2301181","2301181-zarCGiM1aOUmGSgK5BjktNn4p-BPE.jpg","NATIONAL COLLEGE OF PHY EDU CHUPKI DISTT PATIALA","2084","2975","0","70");
INSERT INTO academics VALUES("66","6","189","ECONOMICS","GURU JAMBESHWAR UNIVERSITY OF SCIENCE AND TECHNOLOGY","1996-01-12","Regular","2301183","2301183-eWqslqY15gqkPtzvwHO46Cl1G-MSCDMC.jpg","GURU JAMBESHWAR UNIVERSITY","1370","2200","0","62");
INSERT INTO academics VALUES("67","6","158","Linear algebra functional analysis  probability non linear programming ","Panjab University Chandigarh ","2017-09-08","Regular","2301188","2301188-n2b6ktmHrNGtHebCInBbJiRHH-IMG-20190829-WA0005.jpg","AS college Khanna ","1307","2000","0","65");
INSERT INTO academics VALUES("69","1","1","PUNJABI HINDI ENGLISH S ST SCIENCE MATH","NIOS NEW DELHI","2004-06-01","Correspondence","2301191","2301191-hIOxZaHjTeeoOim3zVXRdbBVJ-10thms.jpg","NIOS NEW DELHI","299","600","0","50");
INSERT INTO academics VALUES("70","2","4","PUNJABI ENGLISH PHY EDUCATION HOME SCIENCE AGRICULTURE","PSEB MOHALI","2008-03-01","Correspondence","2301191","2301191-eDdUKh4F2eCTnrbi5YrnJGCX6-12thms.jpg","PSEB MOHALI","256","450","0","57");
INSERT INTO academics VALUES("71","3","242","LAW SUBJECTS","MAHARAJA GANGA SINGH UNIVERSITY BIKANER RAJ","2017-08-31","Regular","2301191","2301191-6pZsnmKRU3nu4R6dSdWvOsgdO-LLBdgreems.jpg","SHAHEED E AZAM BHAGAT SINGH VIDHI MAHAVIDYALAYA SRI GANGANAGAR RAJ","1339","2700","0","50");
INSERT INTO academics VALUES("73","6","147","LAW SUBJECTS","KALINGA UNIVERSITY NAYA RAIPUR CG","2021-06-15","Regular","2301191","2301191-TEPIcOia1qg4wPMwegHNWNWV1-LLM-4TH.jpg","UNIVERSITY CAMPUS","1593","2400","0","66");
INSERT INTO academics VALUES("74","1","1","HINDI ENGLISH SCI SOC SCI MATHS  PUNJABI","CBSE","2005-05-24","Regular","2301195","2301195-RrjTWk4pPvyG2LPJhsfWgyyid-10th.jpg","DAV CENTENARY PUBLIC SCHOOL  TOHANA","402","500","0","80");
INSERT INTO academics VALUES("75","3","248","PHARMCCEUTICAL SCIENCE","KURUKSHETRA UNIVERSITY KURUKSHETRA","2011-07-22","Regular","2301195","2301195-0ZdMgCI185eou1VyHHs3v7DbF-4thyr.jpg","LORD SHIVA COLLEGE OF PHARMACY","3223","5500","0","59");
INSERT INTO academics VALUES("76","2","2","BIO PHY CHEM HINDI ENG","BOARD OF SCHOOL EDUCATION HARYANA","2007-05-05","Regular","2301195","2301195-UxfjA61iOxlyipdH73noUgnkH-10+2SMAL.jpg","GOVT SR SEC SCHOOL TOHANA","376","500","0","75");
INSERT INTO academics VALUES("77","6","168","PHARMACOLOGY","PUNJAB TECHNICAL UNIVERSITY","2013-11-01","Regular","2301195","2301195-7Xn0YlvZl0c9agTflyiliT3Ln-M.PhFinalSMAL.jpg","RAYAT INSTITUTE OF PHARMACY RAILMAJRA NAWANSHAHAE","1100","676","0","163");
INSERT INTO academics VALUES("78","6","112","computer","PUP","2018-06-21","Regular","2301199","2301199-hQL8TYdM5Li9fejab3pHFOkTH-1675178667037.jpg","Punjabi University","0","0","8","0");
INSERT INTO academics VALUES("79","6","121","Economics","University of Kashmir","2017-12-21","Regular","2301201","2301201-sYhK6pplvF85PqbDeLvEyWDQ8-DocScanner10-Oct-20227-15pm_5.jpg","Department of Economics","1239","2000","0","62");
INSERT INTO academics VALUES("80","6","189","AGRICULTURE","GURU KASHI UNIVERSITY TALWANDI SABO BATHINDA ","2022-12-25","Regular","2301204","2301204-QD2j8plDvUaI80pny14crrznK-c16dcece-1c52-49a5-b727-541e3b543997.jpg","UCOA","0","0","8","0");
INSERT INTO academics VALUES("81","6","164","Gurmat Sangeet","Punjabi University Patiala","2021-12-07","Regular","2301170","2301170-Vh46QnE7J43IooknbVU6ECEfb-IMG_7778(1).jpg","Punjabi University Patiala","0","0","9","0");
INSERT INTO academics VALUES("83","6","172","POLITICAL SCIENCE","PUNJABI UNIVERSITY PATIALA","2019-09-25","Private","2301210","2301210-9NibZ9dlxXAT1bFbpqkwKS7Yk-AnjanaDevi_page-0012.jpg","PUNJABI UNIVERSITY PATIALA","1600","880","0","182");
INSERT INTO academics VALUES("84","6","122","Master of Special Education","DSMNRU LUCKNOW","2018-09-05","Regular","2301208","2301208-PUwVhn36abazcDtiPMnQtXCX1-M.edfinalmarksheet.jpg","DSMNRU LUCKNOW","1249","2000","0","62");
INSERT INTO academics VALUES("85","6","147","ALL LAW SUBJECTS","KURUKSHETRA UNIVERSITY KURUKSHETRA","2021-10-29","Regular","2301215","2301215-IaBTAeQislK4bGpFIgJbRoZQm-llm.jpg","DEPARTMENT OF LAW","1055","1700","0","62");
INSERT INTO academics VALUES("93","3","268","All agricultural subjects ","Centurion University ","2017-02-04","Regular","2301216","2301216-l39DNbJeTX2BbX1XG1EGhmmse-IMG_20201122_165722_copy_583x1036.jpg","Centurion University ","0","0","8","0");
INSERT INTO academics VALUES("94","2","2","Botany zoology physics chemistry English Sanskrit ","State board ","2012-05-10","Regular","2301216","2301216-i81UQscS82V3ZwB1aeIYXLIhM-IMG_20201122_170632_copy_660x1031.jpg","Sri Chaitanya ","1000","753","0","133");
INSERT INTO academics VALUES("95","1","1","Science maths social English telugu ","CBSE","2010-05-28","Regular","2301216","2301216-4zOeHUzb2JqvbjmbCu7b9HYEF-IMG_20210415_190654_copy_1472x1726.jpg","Alluri Sita Ram Raju public school ","0","0","6","0");
INSERT INTO academics VALUES("96","6","189","Genetics and plant breeding ","Allahabad agriculture University ","2019-12-11","Regular","2301216","2301216-JIGQtgT5KzLrJjc1loHMc0hei-IMG_20201122_170759_copy_640x855.jpg","Sam higginbottom University of agriculture and science ","0","0","7","0");
INSERT INTO academics VALUES("97","1","1","ENG PBI HIN MAT SCI SST","PSEB","2005-06-05","Regular","2301167","2301167-AqXxvwcXCzUSvG8n9U4GrOIMY-WhatsAppImage2023-02-04at10.45.07AM.jpeg","DAV Vaish High School ","356","650","0","55");
INSERT INTO academics VALUES("98","2","4","ENG PBC PBI HIS PED ENV","PSEB","2007-08-23","Regular","2301167","2301167-cZHKg8KH6UKLsw8WunxqpYJmb-WhatsAppImage2023-02-04at10.45.04AM.jpeg","Govt Girls School Gidderbaha","328","500","0","66");
INSERT INTO academics VALUES("100","1","1","ENGLISH PUNJABI HINDI MATH SCIENCE SST ","PUNJAB SCHOOL EDUCATION BOARD MOHALI ","1990-07-13","Regular","2301213","2301213-dZg8i3m0XHVO2vaXoPwnuM3LD-20230204000651_00001.jpg","GOVT GIRLS SENIOR SECONDARY SCHOOL BATHINDA","401","800","0","50");
INSERT INTO academics VALUES("101","2","4","ENGLISH PUNJABI PUNJABI ELECTIVE PHYSICAL EDUCATION ECONOMICS ","PUNJAB SCHOOL EDUCATION BOARD MOHALI ","1994-02-03","Regular","2301213","2301213-UWRsnHlvBOyG1RrOb6v9TNlh3-20230204001022_00001.jpg","GOVT GIRLS SENIOR SECONDARY SCHOOL BATHINDA","263","450","0","58");
INSERT INTO academics VALUES("102","3","301","ENGLISH PUNJABI HISTORY ECONOMICS PUNJABI LITERATURE ","PUNJABI UNIVERSITY PATIALA","1997-06-24","Regular","2301213","2301213-hqlCu6N645b9yxmVuXqs8kIji-20230204001624_00001.jpg","GOVT RAJINDRA COLLEGE BATHINDA","1264","2400","0","53");
INSERT INTO academics VALUES("103","6","100","PUNJABI","PUNJABI UNIVERSITY PATIALA","1999-08-10","Regular","2301213","2301213-1J4fq7LBKGsdZtuh6tDVyk8jj-20230204002059_00001.jpg","REGIONAL CENTRE BATHINDA","470","800","0","59");
INSERT INTO academics VALUES("104","6","171","PHYSICS","KASHMIR UNIVERSITY","2014-07-24","Regular","2301217","2301217-mVpdFWkUsYs4UWQaAEph5Orak-index.jpg","SP COLLEGE  SRINAGAR","1138","2100","0","54");
INSERT INTO academics VALUES("106","6","102","Management ","Punjabi University Patiala","2019-08-17","Regular","2301220","2301220-pLqM4n3kZPqs7aqiaPuDGtOD3-IMG_0409(1).PNG","Punjabi university ","0","0","8","0");
INSERT INTO academics VALUES("107","6","171","Physics","CDLU SIRSA","2016-08-31","Regular","2301205","2301205-FbTUNce6np98Ri4V0k660Q3eC-9B17F107-6EF8-4998-B6EA-CE08291C7CC5.jpeg","CDLU SIRSA","1910","2400","0","80");
INSERT INTO academics VALUES("108","3","336","Physics Chemistry Maths","CDLU SIRSA","2014-06-27","Regular","2301205","2301205-Ng2aQdGyS1nrs9frNRIrbGT35-048989EA-0AF6-46CF-9926-36B1CE38037F.jpeg","C M K NATIONAL GIRLS COLLEGE SIRSA","2391","2900","0","82");
INSERT INTO academics VALUES("109","2","3","Physics Chemistry Maths English Music","CBSE","2011-05-23","Regular","2301205","2301205-FKjwzvWxbqXp7AFmIuDG8ehsf-9FFFA9A7-8880-4567-B9C7-081C3E2CCE64.jpeg","G R G NATIONAL GIRLS SR SEC SCHOOL SIRSA","413","500","0","83");
INSERT INTO academics VALUES("110","1","1","English Hindi Maths Science SS Introductory I T","CBSE","2009-05-26","Regular","2301205","2301205-IHfqrOng0fUnUg0w3yzDM5vId-7C10BE8E-FF1B-4A2E-BCBC-4E59A2E74330.jpeg","G R G NATIONAL GIRLS SR SEC SCHOOL SIRSA","523","600","0","87");
INSERT INTO academics VALUES("111","6","100","PUNJABI","CDLU HARYANA","2023-01-12","Regular","2301211","2301211-lVZ0CVZsA2XiuYc627TaWhRdi-20001.JPG","GNC SIRSA","1551","2700","0","57");
INSERT INTO academics VALUES("113","6","112","All as per Syllabus","GKU","2014-08-29","Regular","2301005","2301005-Kq1yVgTF0R8WT6Tu16aiCk49h-MCA_Degree1(FILEminimizer).JPG","UCCA","0","0","7.92","0");
INSERT INTO academics VALUES("114","3","231","All as per Syllabus","Pbi Uni Patiala","2011-07-11","Regular","2301005","2301005-ADW3pcccTbGggaVokDbG9yD1I-BCA_Degree(FILEminimizer).JPG","Guru Kashi College Talwandi Sabo","1320","2200","0","60");
INSERT INTO academics VALUES("115","2","4","Math Eco Phy edu","PSEB","2006-06-05","Regular","2301005","2301005-WEoO643MLw8FPIjYmp8kiOAKD-+2(FILEminimizer).JPG","Khalsa Sec School T sabo","290","450","0","64");
INSERT INTO academics VALUES("116","1","1","All as per Syllabus","PSEB","2004-06-27","Regular","2301005","2301005-nprNE3MdvumpwHhQlC67gZkiC-gjgj.JPG","Govt Sec School Bhagi Wander","490","650","0","75");
INSERT INTO academics VALUES("117","3","353","BPED ALL SUBJECTS","PUNJABI UNIVERSITY PATIALA","2013-07-22","Regular","2301167","2301167-QJZDb7TbFXjtSxpDJRkvBW5Sx-WhatsAppImage2023-02-05at6.56.56PM(1).jpeg","MALWA COLLEGE OF PHYSICAL EDUCATION","934","1250","0","75");
INSERT INTO academics VALUES("118","6","121","Economics ","Punjabi University Patiala","2018-05-01","Distance","2301202","2301202-uP11eKurThalUZxSgZg98SCYE-20230205_213142.jpg","Department of distance education ","1012","1600","0","63");
INSERT INTO academics VALUES("119","6","361","PHYSICAL EDUCATION ","PUNJABI UNIVERSITY PATIALA","2015-07-21","Regular","2301167","2301167-RqiDRlsQjcJEO9FMTNQ0uMw7u-MPED.jpeg","AKAL COLLEGE OF PHYSICAL EDUCATION","1118","1500","0","75");
INSERT INTO academics VALUES("120","6","102","all","NA","2022-06-10","Regular","2301226","2301226-qhzeBhebDzisz45v8Bmduc6kn-download.png","NA","800","1000","0","80");
INSERT INTO academics VALUES("121","6","189","fruit science ","guru kashi university ","2023-01-05","Regular","2301228","2301228-LXNq0mVvEeUQJHSRYooAHTsoM-DB37031B-A56B-45DD-815C-6183795839F8.png","UCOA","0","0","9.4","0");
INSERT INTO academics VALUES("122","6","122","Education","Panjab University Chandigarh","2014-04-08","Regular","2301231","2301231-tJod0Gh8IGbkRHGawj5T5BB7n-M.Ed(1).jpg","MCEG Ghall Kalan Moga","508","650","0","78");
INSERT INTO academics VALUES("123","6","102","HR and Healthcare","Bangalore North University","2021-12-04","Regular","2301233","2301233-3siQC2A8JtqZlqPMquYnukAzE-IMG_20230307_113626.jpg","Koshys Institute of Management Studies","0","0","7.8","0");



CREATE TABLE `basic_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(50) NOT NULL,
  `course` varchar(150) NOT NULL,
  `discipline` varchar(150) NOT NULL,
  `fee` int(10) NOT NULL,
  `candidate_name` varchar(150) NOT NULL,
  `father_name` varchar(150) NOT NULL,
  `mother_name` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `marital_status` varchar(150) NOT NULL,
  `gender` varchar(150) NOT NULL,
  `mobile_no` varchar(150) NOT NULL,
  `adhar_no` varchar(200) NOT NULL,
  `pan_no` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `sign` varchar(150) NOT NULL,
  `permanent_address` varchar(200) DEFAULT NULL,
  `correspondence_address` varchar(200) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `submit_date` date NOT NULL,
  `entrance` int(11) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `lock_status` varchar(50) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `payment_id` bigint(50) DEFAULT NULL,
  `candidate_status` varchar(50) DEFAULT NULL,
  `payment_reference_no` varchar(50) DEFAULT NULL,
  `resume` varchar(150) NOT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_basic_detail_recruitment` (`entrance`),
  CONSTRAINT `FK_basic_detail_recruitment` FOREIGN KEY (`entrance`) REFERENCES `entrance` (`r_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2301237 DEFAULT CHARSET=utf8mb4;

INSERT INTO basic_detail VALUES("2301005","123456","Ph.D.","Computer Applications","3000","Amrik Singh","Harminder Singh","Harpreet Kaur","1988-06-25","Married","Male","9815795495","568391148198","AAAAA1111A","ratandeep2@gmail.com","2301005-jdO69NKD9DwAIqh60aANySYRu-Image-asda.jpg","2301005-vX2Owlw9Anrd8qBSDr4nq5RGp-Sign-sign.jpg","VPO Bhagi Wander Talwandi Sabo Bathinda","VPO Bhagi Wander Talwandi Sabo Bathinda","UR","2023-01-07","7","2023-02-06","2023-05-02","unlocked","success","16735581572","Completed","20230205050623fuqxNDyLE4vktRmsY5DHlSmNh","","131053");
INSERT INTO basic_detail VALUES("2301006","283830","Ph.D.","Civil Engineering","1","Amrik","Ggh","sssss","2023-01-12","Unmarried","Female","9815795495","789546241523","AAAAA1111A","ratandeep2@gmail.com","2301006-dPgTNTqfJVpqAYA8rx0H7UITs-Image-121009.jpg","2301006-3As7lJqRdvR59YkUzRQoZpuOX-Sign-epf.jpeg","werw","wewr","UR","2023-01-07","7","2023-02-06","2023-01-07","unlocked","","16547619753","pending","20230107082504OM4nQhqAV8IgS9pajsXQf8VJh","","131053");
INSERT INTO basic_detail VALUES("2301007","646487","Ph.D.","Education","3000","Ram Saran","Sukkha Ram","","1979-12-18","","","9013497882","","","saranram877@gmail.com","","","","","","2023-01-08","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301008","846957","Ph.D.","Law","3000","GURDAS SINGH","HARBANS SINGH","","1990-10-06","","","9463003330","","","gurdasdahot@gmail.com","","","","","","2023-01-08","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301009","381917","Ph.D.","Education","3000","Neeru","Sant Singh","Leelawanti","1976-05-10","Unmarried","Female","9463997869","521940018767","AAAAA1111A","neeru10576@gmail.com","2301009-mfupZEmQUkZRsE4PiDCLJrFxs-Image-PHOTO(1).jpg","2301009-ZOXpmNx4XE59JbfWhLlSkwgUZ-Sign-SIG.jpg","H No.17/336, Street No.7 Akalsar Road opp. Sardar Nagar Moga","H No.17/336, Street No.7 Akalsar Road opp. Sardar Nagar Moga","UR","2023-01-08","7","2023-02-06","","","","","Pending","20230123073714uKABk0bxRbV9pHD74ABWslehR","","");
INSERT INTO basic_detail VALUES("2301010","355560","Ph.D.","Computer Applications","3000","Mandeep Kaur","Jasbir Singh","Paramjeet Kaur","1983-11-05","Married","Female","7888957751","715771817168","AAAAA1111A","mandeeparora511@gmail.com","","","S sp Singh,Rimpy cottage,
#149, phase 1 model town near tv tower Bathinda Punjab","S sp Singh,Rimpy cottage,
#149, phase 1 model town near tv tower Bathinda Punjab","UR","2023-01-08","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301133","485997","Ph.D.","Political  Science","3000","niru sharma","Leela Parshotam","Sunita Rani","1988-12-02","Married","Female","9888651203","794205284726","AAAAA1111A","nirusharma778@gmail.com","","","House no 63, Aman city vill chanlon kurali Mohali Punjab 140103","House no 63, Aman city vill chanlon kurali Mohali Punjab 140103","UR","2023-01-08","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301134","413760","Ph.D.","Physical Education","3000","ASLAM KHAN","FAIJU KHAN","","1988-11-25","","","9119163786","","","aslmkhn458@gmail.com","","","","","","2023-01-08","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301135","659547","Ph.D.","Political  Science","3000","Sumit Bhoker","Balraj Singh","Nirmala devi","1995-11-02","Unmarried","Male","9017555533","212188893827","AAAAA1111A","sumit1995bhoker@gmail.com","","","House no -45, Vpo- Diwana, District & Tehsil- panipat, State - Haryana, Pin code - 132108","House no-45, Vpo- Diwana,  District & tehsil - Panipat , State - Haryana, Pin code -132108","UR","2023-01-09","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301136","517196","Ph.D.","Physical Education","3000","MOHAMMAD MUDASSIR PAYER","SAFE UD DIN PAYER","NASEEMA BAGUM ","1996-03-10","Unmarried","Male","6005743692","629570118309","AAAAA1111A","payermudasir70@gmail.com","","","SULKOOT KUPWARA ","SULKOOT KUPWARA ","UR","2023-01-09","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301137","920628","Ph.D.","Agronomy","3000","Anurag","Shivaji","Alka","1992-08-12","Unmarried","Male","8287262119","284523319415","AAAAA1111A","anuragkale111@gmail.com","2301137-qXRLe47eD7osXJ00kgJSkxruq-Image-IMG_20211013_194327.jpg","2301137-UR1JkxpC3fpI9EXryC4tzEzAP-Sign-4-1.jpg","At post Kodi Karla Taluka Jalna District Jalna Maharashtra 431203","At post Kodi Karla Taluka Jalna District Jalna Maharashtra 431203","UR","2023-01-09","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301138","218223","Ph.D.","Political  Science","3000","Sheikh Mohmad Saleem","Gh Mohmad","","1992-10-31","","","6005912208","","","mohmadsalim5334@gmail.com","","","","","","2023-01-10","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301139","149529","Ph.D.","Computer Applications","3000","KAMALJIT KAUR","AJAIB SINGH","BIMAL KAUR","1981-11-15","Married","Female","9478162947","242859811722","AAAAA1111A","kamalmadhursaini@gmail.com","2301139-q3FS3TtdtuxRxQOQ3wIOnqbaJ-Image-PHOTO.jpeg","2301139-qOwUUKHhRCRDRI8p8NAjW7Pxn-Sign-SIGN.jpeg","H NO.2933, B32, ST NO 4, SHIMLA COLONY, KAILASH NAGAR ROAD, BASTI JODHEWAL, LUDHIANA, PUNJAB, PIN CODE 141007","H NO.2933, B32, ST NO 4, SHIMLA COLONY, KAILASH NAGAR ROAD, BASTI JODHEWAL, LUDHIANA, PUNJAB, PIN CODE 141007","SC","2023-01-10","7","2023-02-06","0000-00-00","","success","16602331222","Completed","20230115113036APo2n59O0Nl3nrQzOuTaw2WEU","","");
INSERT INTO basic_detail VALUES("2301140","518469","Ph.D.","Education","3000","Sonia","Dilbag Singh","","1986-03-29","","","9779177661","","","advmschauhanbti@gmail.com","","","","","","2023-01-10","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301141","161530","Ph.D.","Entomology","3000","Tanvi Asija","Parveen kumar","","1996-06-25","","","9991512128","","","tanviasija1996@gmail.com","","","","","","2023-01-11","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301142","482791","Ph.D.","Political  Science","3000","GOWHAR BASHIR","BASHIR AHMAD GANAI","Shameema","1988-02-21","Unmarried","Male","9622203043","331422692429","AAAAA1111A","ghaazigowhar@gmail.com","2301142-1LLqNZrsg6Rdfdwbs7kIi8hzS-Image-PIC.jpg","2301142-Yp2Lw0czAJHfJTeixykYJSjsM-Sign-imresizersign.jpg","DANGAR PORA PULWAMA KASHMIR ","DANGAR PORA PULWAMA KASHMIR ","UR","2023-01-11","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301143","672241","Ph.D.","Economics","3000","ANURATI","RAJ KUMAR","ANJU","1999-03-28","Unmarried","Female","7015326229","461061297029","AAAAA1111A","anuratisachdeva@gmail.com","2301143-F4tticHXayeZnR79n95vThYkv-Image-525004-Copy.jpg","2301143-6qWOwuf8edcefZ345pYZA6Qzp-Sign-525004.jpg","263-D ARORVANSH MOHALLA, WARD NO 3, MAIN BAZAR, FATEHABAD, HARYANA-125050","263-D ARORVANSH MOHALLA, WARD NO 3, MAIN BAZAR, FATEHABAD, HARYANA-125050","UR","2023-01-12","7","2023-02-06","0000-00-00","","success","16612305938","Completed","20230117031612qCwSFHSU9Fz5fodjw6WJCt9kf","","");
INSERT INTO basic_detail VALUES("2301144","222461","Ph.D.","Punjabi","3000","jaspal singh","Ranjeet singh","","1989-07-28","","","9728648701","","","jaspalrori007@gmail.com","","","","","","2023-01-13","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301145","794989","Ph.D.","Agriculture Economics","3000","Ruth chinkoyo","Tomson chisale","","2023-08-19","","","0772131541","","","ruthyychinkoyo@gmail.com","","","","","","2023-01-14","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301146","548242","Ph.D.","Punjabi","3000","Pargat singh","Jarnail singh","","1989-09-03","","","8146356893","","","pargatsinghkhalsa6758@gmail.com","","","","","","2023-01-15","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301147","517892","Ph.D.","Education","3000","MANPREET KAUR","GURDEEP SINGH","MANJEET KAUR","1993-02-20","Married","Female","9988400311","824781511221","AAAAA1111A","sidhumanpreet13370@gmail.com","2301147-HXwgV5wKqrzhA83bTDv57NCwX-Image-CTET.JPG","2301147-YRSHFoByNFZBfBABuTURwzFby-Sign-CTETS.JPG","W/O MANINDERDEEP SINGH, STREET NO 01, LINK ROAD, MANSA","W/O MANINDERDEEP SINGH, STREET NO 01, LINK ROAD, MANSA","UR","2023-01-16","7","2023-02-06","0000-00-00","","success","16634375454","Completed","20230120080635rbJQmEgrff0VNjNXABDHrQjCT","","");
INSERT INTO basic_detail VALUES("2301148","357426","Ph.D.","Entomology","3000","Aishwarya Anil Lavhade","Anil","Shakuntala","1998-02-25","Unmarried","Female","7447332008","759412320549","AAAAA1111A","lohadeaishwarya1998@gmail.com","","","Dr. Zakir Hussain Nagar, Sillod","Dr. Zakir Hussain Nagar, Sillod","UR","2023-01-16","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301149","527689","Ph.D.","Punjabi","3000","BEANT KAUR","BALDEV SINGH","KULWINDER KAUR","1978-10-04","Married","Female","8360347384","357436831995","AAAAA1111A","gillbeant49@gmail.com","2301149-VAZFBuRkjqMeegPtJci4lKu1p-Image-G.jpg","2301149-yj0AJkwwJoFz1bbk2vFI4g8f0-Sign-005.jpg","H NO 20/618 ST NO 01 PREM NAGAR MOGA 142001","H NO 20/618 ST NO 01 PREM NAGAR MOGA 142001","UR","2023-01-16","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301150","820988","Ph.D.","Economics","3000","Manpreet Kaur","Mangal Singh","Beant Kaur","1989-10-30","Married","Female","9817498674","832578860728","AAAAA1111A","3010manpreet@gmail.com","2301150-UMrfJx55FoDydBXA75fxso714-Image-photo.jpeg","2301150-QFTAmhjI5RDfTN1URv1pSZz91-Sign-sign.jpeg","H.No. 92, Telephone Exchange Colony, Zirakpur (140603)","H.No. 92, Telephone Exchange Colony, Zirakpur (140603)","UR","2023-01-16","7","2023-02-06","0000-00-00","","success","16650419425","Completed","20230122235618cwpJESudMyYfrsjrZzuT3kVhw","","");
INSERT INTO basic_detail VALUES("2301151","601181","Ph.D.","Physical Education","3000","RAMANDEEP KAUR","GURVINDER SINGH","SUKHDEEP KAUR","1989-12-10","Married","Female","9915907942","323883799467","AAAAA1111A","ramusandhu6565@gmail.com","","","VILLAGE MALL SINGH WALA PO BOHA TEH SIL BHUDLADA DISTT. MANSA","VILLAGE MALL SINGH WALA PO BOHA TEH SIL BHUDLADA DISTT. MANSA","UR","2023-01-16","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301152","305620","Ph.D.","Law","3000","Rajbir Kaur","Paramjit Singh","Ravinder Kaur","1988-03-09","Married","Female","9780040997","714757020907","AAAAA1111A","rajbir9@yahoo.com","2301152-kMAHISjpIf2qNHfy7HpegIMYF-Image-IMG-20230120-WA0009.jpg","2301152-knRMoV3uRTIGwgYfGzAfCKW3N-Sign-IMG-20230120-WA0011.jpg","Rajbir Kaur D/O Paramjit Singh, Dalip Singh and Sons, Dhuri Road, Mahavir Chowk, Sangrur 148001","Rajbir Kaur D/O Paramjit Singh, Dalip Singh and Sons, Dhuri Road, Mahavir Chowk, Sangrur 148001","BC","2023-01-17","7","2023-02-06","0000-00-00","","success","16634927398","Completed","20230120092632oZmK6URYlEA6reG6wWHgf8YD0","","");
INSERT INTO basic_detail VALUES("2301153","317207","Ph.D.","Computer Applications","3000","HARPREET KAUR","HARBHAJAN SINGH","SUKHWINDER KAUR","1992-10-09","Unmarried","Female","7009382425","397717935022","AAAAA1111A","h1312504@gmail.com","","","NEAR BAGLA MARKET TIBBI SAHIB ROAD, SHRI MUKTSAR SAHIB","NEAR BAGLA MARKET TIBBI SAHIB ROAD, SHRI MUKTSAR SAHIB","OBC","2023-01-17","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301154","344492","Ph.D.","Punjabi","3000","Jagtar Singh","Achhara Singh","Harjinder Kaur","1983-03-28","Married","Male","9876755561","868166475192","AAAAA1111A","ranujagtar@gmail.com","2301154-OfOSJC3xv0uuZUEtiN1N3BctC-Image-compreesimg.jpg","2301154-MeD3xtIUJ0iU8RXiovs5oyg8m-Sign-comprsssgn.jpg","VPO-Hamidi, Tehsil and District-Barnala","VPO-Hamidi, Tesil and District-Barnala","","2023-01-17","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301155","865615","Ph.D.","Political  Science","3000","POOJA","Tarsem kumar","Darshana","1980-01-31","Married","Female","9417753897","329829634042","AAAAA1111A","lrpsprincipal@gmail.com","2301155-N122sF5WiFgD1UW2e5PL6HgGR-Image-POOJAMAM.jpg","2301155-8LjkljWBotTjhFqNk2WfycFMb-Sign-SINGPOOJA.jpg","Kothi no 213 , Urban Estate , Phase 1, Bathinda ","Kothi no 213 , Urban Estate , Phase 1 , Bathinda ","UR","2023-01-18","7","2023-02-06","0000-00-00","","success","16637233713","Completed","202301202248454DAgOFn5Wtn0lkIg4HPSxdhTd","","");
INSERT INTO basic_detail VALUES("2301156","934543","Ph.D.","Political  Science","3000","BALDEV KUMAR","AMAR CHAND","PRAKASHO","1969-05-24","Married","Male","9872440141","473655073801","AAAAA1111A","baldev.kumar001@gmail.com","2301156-5Si13OMxVnBpds9Don8TDbcDN-Image-IMG_20230120_120646.jpg","2301156-CAxT2BrAvENPXIpz5QgygooCx-Sign-IMG_20230120_120942.jpg","V.P.O. MOHEM TEHSIL NAKODER DISTT JALANDHAR PIN CODE 144040","V.P.O. MOHEM TEHSIL NAKODER DISTT JALANDHAR PIN CODE 144040","SC","2023-01-19","7","2023-02-06","0000-00-00","","success","16631868713","Completed","20230120013044EVxf6DekcS4oWhhcqo32Cn3ep","","");
INSERT INTO basic_detail VALUES("2301157","985319","Ph.D.","Law","3000","Diganta Sarania","Devdas Saraniah","","1987-03-01","","","8724926889","","","digantadev.sarania@gmail.com","","","","","","2023-01-21","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301158","771062","Ph.D.","Physics","3000","gourav sharma","virender sharma","prem lata","1999-02-23","Unmarried","Male","8968290318","951795393723","AAAAA1111A","sharmaji8968@gmail.com","2301158-qYlxTp26Muql9lr0vGVKNAx0K-Image-PPHOTO.jpg","2301158-ZrF6YMw6JPKRBrKEMrMuYgz2N-Sign-fc37a716-6e3e-461d-bea3-dfb9a6061c11.jpg","Naushera, army colony, tibri cannt, gurdaspur
pin:143530
post office : Pull tibri","Naushera, army colony, tibri cannt, gurdaspur
pin:143530
post office : Pull tibri","UR","2023-01-21","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301159","578063","Ph.D.","Education","3000","Md Ashraful Islam","Md Shamsul Islam","","1985-02-12","","","1711991268","","","ashrafulomc@gmail.com","","","","","","2023-01-22","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301160","482584","Ph.D.","Computer Applications","3000","Rohit Sharma","Lekh Raj Sharma","","1985-08-13","","","8283819697","","","rohit.hodcs@gmail.com","","","","","","2023-01-23","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301161","264490","Ph.D.","Plant Breeding and Genetics","3000","Gaddam Tarun","Gaddam Ramesh Babu","Gaddam Sriindrani ","1998-08-28","Unmarried","Male","7981883175","460924836471","AAAAA1111A","iamtarungaddam@gmail.com","2301161-XfvmNVWUaacxzdmem4t5yZuhV-Image-IMG-20220921-WA0006_copy_286x392.jpg","2301161-a4rgKkGOEoGqxTcQv0uezbAIJ-Sign-IMG-20220814-WA0000_copy_450x255.jpg","27-045-1578, gopal nagar 4th line extension, opposite church, Ongole, Prakasam, Andhra pradesh, 523001","27-045-1578, gopal nagar 4th line extension, opposite church, Ongole, Prakasam, Andhra pradesh, 523001","OBC","2023-01-23","7","2023-02-06","0000-00-00","","success","16694510384","Completed","20230130073619rtVzl3ztjFsZlPng8fPovQvmy","","");
INSERT INTO basic_detail VALUES("2301162","397681","Ph.D.","Punjabi","3000","Harjit Singh","Baltej Singh","Jasvir Kaur","1989-08-20","Married","Male","9878304562","312032450026","AAAAA1111A","harjeetsran@gmail.com","2301162-SSze6JS5XeuCJ3uwxX9MHiIDn-Image-55pc-1.jpg","2301162-lAuF0fuSs6dYiQr8xJ9OugUKb-Sign-2013-05-0920.12.35-1.jpg","VPO Bhaini Bagha,House No 318,Near Saho Patti Dharmshala, Teh&Dist. Mansa","VPO Bhaini Bagha,House No 318,Near Saho Patti Dharmshala, Teh&Dist. Mansa","UR","2023-01-23","7","2023-02-06","0000-00-00","","success","16656477665","Completed","202301232349488FnZwxg5iF3kN4gZjfSgIKjkx","","");
INSERT INTO basic_detail VALUES("2301163","649240","Ph.D.","Economics","3000","vijay sonkar","rajendra sonkar","munni sonkar","1993-02-22","Married","Male","8369869747","695960121356","AAAAA1111A","vjsonkar80@gmail.com","","","Room no 40, New Bharat Nagar, Vashi Naka, Chembur, Mumbai -400074","Room no 40, New Bharat Nagar, Vashi Naka, Chembur, Mumbai -400074","SC","2023-01-23","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301164","937151","Ph.D.","Law","3000","DALBIR SINGH","JAGDISH","MANPATI ","1986-01-15","Married","Male","9812625297","862547586259","AAAAA1111A","advdalbir86@gmail.com","","","DALBIR SINGH S/O SH. JAGDISH , VPO- MATANA , NEAR -VERMA JI CHOWK MATANA , TEHSIL AND DISTT - FATEHABAD , HARYANA , PIN - 125050","DALBIR SINGH S/O SH. JAGDISH , VPO- MATANA ,NEAR- VERMA JI CHOWK MATANA , TEHSIL AND DISTT.- FATEHABAD , HARYANA ,PIN -125050","OBC","2023-01-23","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301165","449952","Ph.D.","Punjabi","3000","Pushwinder Kaur","NetaShan Singh","Charanjit Kaur","1986-07-12","Married","Female","9915607130","999427676357","AAAAA1111A","pushwinderk87@gmail.com","2301165-njVFP1w63MfMJLLD2qTRHe2kB-Image-Picp.jpeg","2301165-hcWRT9vhhExGXdDuFgTnoHJn2-Sign-SignP.jpeg","Pushwinder Kaur w/o Amandeep Singh,Vill. Bhai Desa,Near Jyoti Seeds,PO Kotli Kalan, Teh&Dist. Mansa","Pushwinder Kaur w/o Amandeep Singh,Vill. Bhai Desa,Near Jyoti Seeds,PO Kotli Kalan, Teh&Dist. Mansa","UR","2023-01-24","7","2023-02-06","0000-00-00","","success","16656737104","Completed","20230124002835lb4oFBQ3UY03D31PBb5DaDwTL","","");
INSERT INTO basic_detail VALUES("2301166","563429","Ph.D.","Pharmacy","3000","AMITPAL SINGH","BAKSHISH SINGH","SARABPREET KAUR","1987-09-20","Unmarried","Male","7087780065","367616631485","AAAAA1111A","dramit356@gmail.com","","","282 BX MODEL TOWN EXTENSION LUDHIANA","282 BX MODEL TOWN EXTENSION LUDHIANA","UR","2023-01-24","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301167","775039","Ph.D.","Physical Education","3000","Sarbjit kaur","Jagnandan singh","Veerpal kaur","1989-07-26","Married","Female","7986135148","662607160759","AAAAA1111A","sarbjitmann185@gmail.com","2301167-6KjNkpQ5avUKxP3WKNpUozBaN-Image-sarbphoto.jpeg","2301167-F0OaephH2EK72MO2NiG9dt9Lp-Sign-sarbsign.jpeg","Sarbjit kaur c/o butta Singh Raj hospital wali main gali Mandi killianwali pin code 151211","Sarbjit kaur c/o butta Singh Raj hospital wali main gali Ajit nager mandi killianwali pin code 151211","UR","2023-01-25","7","2023-02-07","2023-06-02","","success","16742176311","Completed","20230206041808TlSnFWUKqSX3u65wRNMZpY7p1","","");
INSERT INTO basic_detail VALUES("2301168","936128","Ph.D.","Computer Applications","3000","Santosh rani","Krishan gopal","","1984-08-14","","","9050665522","","","santoshmehta1423@gmail.com","","","","","","2023-01-25","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301169","282382","Ph.D.","Law","3000","Angel","Edward","","2004-07-17","","","0768564625","","","angelkarabo756@gmail.com","","","","","","2023-01-25","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301170","233454","Ph.D.","Religious Studies","3000","Leena Singh","Surinder Singh Bedi","Devinder Bedi","1970-12-28","Married","Female","4082198027","000000000000","AAAAA1111A","leena.bedi@gmail.com","2301170-JutTBvAsKvOcoJ1P21FNmoxyV-Image-leena.jpg","2301170-2nxmkaQUAu9VADvCSN8TuHJML-Sign-IMG_7757.jpg","1108 November Dr, 
Cupertino, 
CA, USA  95014","1108 November Dr, 
Cupertino, CA, 
USA  95014","UR","2023-01-25","7","2023-02-06","2023-04-02","","success","16733091451","Completed","20230204231330vho5YIqRN6iqXxj62ABuinuGo","","");
INSERT INTO basic_detail VALUES("2301171","205470","Ph.D.","Political  Science","3000","Anita Rani","Devraj Sharma","PUSHPA RANI","1979-09-07","Married","Female","9465617506","744281965777","AAAAA1111A","anitasharma01979@gmail.com","2301171-VQGifGcbCz7KjDmnLD5IhiFyW-Image-WhatsAppImage2023-01-27at9.13.57PM(2).jpeg","2301171-Nl9E0uNFZAUsQYN4vNLM3fVgA-Sign-WhatsAppImage2023-01-27at9.17.44PM.jpeg"," V.P.O. JANDANWALA  NEAR VILLAGE DHARAMSHALA ,DISTRICT BATHINDA 151201","# 10679  STREET NO. 5 SUCHA SINGH NAGAR ,BATHINDA  151001 LANDMARK  OPPOSITE LAKE NO. 2 ","UR","2023-01-25","7","2023-02-06","0000-00-00","","success","16677631806","Completed","20230127102501MnJotvgSPs7m24OT3EfcvsBbM","","");
INSERT INTO basic_detail VALUES("2301172","494736","Ph.D.","Vegetable Science","3000","Harsimranjeet Singh","Manjeet Singh","Amarjeet Kaur","1996-04-27","Unmarried","Male","9646722349","682681929668","AAAAA1111A","harsimran4951@gmail.com","","","VOP. Wara Waryam Singh District Ferozepur Tech Zira 142050","Baldev Singh S/O Ram Singh Muhalla Mahi Khana Street No.4 Faridkot, Punjab 151203","UR","2023-01-26","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301173","224580","Ph.D.","Physical Education","3000","Rashid","Hanif","","1987-01-01","","","9142285257","","","rashidalam378056@gmail.com","","","","","","2023-01-26","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301174","928111","Ph.D.","Mathematics","3000","Vimal Kumar","Jaipal","Anita Devi","1993-01-07","Married","Male","9896756910","319048660845","AAAAA1111A","vimalkumar3@live.com","2301174-KC5px1YsCMs2I6gvJNzsXFETG-Image-VimalPic.jpg","2301174-P4YN2ObMctgbmTE00fdhrqsIA-Sign-vimalsign.jpg","VPO Bakhli, Tehsil Pehowa, District Kurukshetra, Haryana (136128)","VPO Bakhli, Tehsil Pehowa, District Kurukshetra, Haryana (136128)","UR","2023-01-26","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301175","636196","Ph.D.","Computer Applications","3000","Uzma khursheed","Peer Khursheed Ahmad","","1995-11-03","","","7051889347","","","uzma3148@gmail.com","","","","","","2023-01-26","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301176","187958","Ph.D.","Pharmacy","3000","RAKESH SHUKLA","Santosh Kumar Shukla","","1999-07-07","","","8318819670","","","rakeshshukla779@gmail.com","","","","","","2023-01-26","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301177","802516","Ph.D.","Agriculture Economics","3000","Dennis Kennedy","Dennis Kennedy","","2003-03-27","","","0973960646","","","chitundu28@gmail.con","","","","","","2023-01-27","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301178","525992","Ph.D.","Computer Applications","3000","Abid Shahim Aziz","Abdul Aziz","","1985-01-13","","","9447866183","","","abidshahim@gmail.com","","","","","","2023-01-27","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301179","747602","Ph.D.","Agriculture Economics","3000","Dennis Kennedy","Dennis Kennedy","","2003-03-27","","","0964733110","","","madmykkennedy@gmail.com","2301179-OZeQNMLaUSkEE4uIs52op9cNf-Image-26692982-7F7F-45EB-8D35-A9113CE1FA4A.jpeg","2301179-929gPTPHigfJTfg1NwKpv0Yel-Sign-4C5F6341-7DB7-45A5-AE19-343F9AF1D769.jpeg","","","","2023-01-27","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301180","155636","Ph.D.","Physics","3000","Iqbal singh","Gurtej singh","Jaswinder kaur","1999-01-11","Married","Male","9625538427","992789060977","AAAAA1111A","iqbalsingh7154@gmail.com","","","Vpo lohgarh,district sirsa","Vpo lohgarh,district sirsa","OBC","2023-01-27","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301181","657091","Ph.D.","Physical Education","3000","AMANDEEP KAUR","SAROOP SINGH","RAJWANT KAUR","1987-04-13","Unmarried","Female","9779955417","989946099807","AAAAA1111A","amandeep4177@gmail.com","","","BACK SIDE COURT COMPLEX, 33 FEET ROAD, NEAR SS MITTAL SCHOOL, MANSA-151505","BACK SIDE COURT COMPLEX, 33 FEET ROAD, NEAR SS MITTAL SCHOOL, MANSA-151505","UR","2023-01-28","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301182","940449","Ph.D.","Computer Applications","3000","DADALA SRNIVAS","KASULU","","1980-06-03","","","9908453536","","","kietdskiet@gmail.com","","","","","","2023-01-28","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301183","900245","Ph.D.","Agriculture Economics","3000","NISHA","AJEET SINGH","SUSHILA DEVI","1996-01-12","Married","Female","8168970192","685002338479","AAAAA1111A","nishakhatak02@gmail.com","2301183-SpdtQxErWZD5grY1IKlYMs26C-Image-nishapic.jpg","2301183-urCBJraG5HYCtLLPWzOKHpVZ3-Sign-nishusing..jpg","HNO 9 VIKAS COLONY KAIMIRI ROAD HISAR","HNO 9 VIKAS COLONY KAIMIRI ROAD HISAR","SC","2023-01-28","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301184","920453","Ph.D.","Plant Pathology","3000","SHAIK RIYAZUDDIN","SHAIK ALLAHUDDIN","SHAIK GOUSIA SULTHANA","1998-08-22","Unmarried","Male","9640381101","576095890238","AAAAA1111A","riyazuddinsk104@gmail.com","2301184-sl3HoZ3e82HdgRWbv0t684pe6-Image-po.jpg","2301184-e61UXrrX6DYutJTTO0tM2uRtI-Sign-SIGN-Copy.22.jpg","31-114-1 AAZAD STREET, PURUSHOTA PATNAM.
CHILAKALURIPETA 522616.
PALNADU DISTRICT, ANDHRA PRADESH.","31-114-1 AAZAD STREET, PURUSHOTA PATNAM.
CHILAKALURIPETA 522616.
PALNADU DISTRICT, ANDHRA PRADESH.","BC","2023-01-28","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301185","995355","Ph.D.","Civil Engineering","3000","Deeksha Bajpai","Rajeev Bajpai","Reena bajpai","1999-10-31","Unmarried","Female","8840117959","388457715710","AAAAA1111A","bajpaideeksha1999@gmail.com","","","538k/737 Triveni Nagar 1st sitapur road lucknow","538k/737 Triveni Nagar 1st sitapur road lucknow","UR","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301186","104827","Ph.D.","Physical Education","3000","Surjeet kaur","Gulzar Singh","","1971-03-28","","","9050860548","","","kaursurjeet2011@gmail.com","","","","","","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301187","108972","Ph.D.","Political  Science","3000","Amit kumar","Ishwar singh","Kamlesh devi","1995-11-05","Unmarried","Male","9654110661","911963216401","AAAAA1111A","mamitdangi@gmail.com","","","Village nolaza 
Vpo nangal nunia
Narnaul haryana
Pin 123023","Village nolaza 
Vpo nangal nunia
Tehsil narnaul Haryana
Pin code 123023","UR","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301188","107342","Ph.D.","Mathematics","3000","Hardeep kumar","Ram Shanker Pal","Sonia ","1993-04-28","Unmarried","Male","8360728337","638211790901","AAAAA1111A","khappy893@gmail.com","","","Hno 267 Sec 9b Ram Nagar ,Mandi Gobindgarh, Dist. Fatehgarh Sahib, Punjab ","Hno 267 Sec 9b Ram Nagar ,Mandi Gobindgarh, Dist. Fatehgarh Sahib, Punjab ","OBC","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301189","848271","Ph.D.","Fruit Science","3000","Amar deep Singh Chauhan","Bhanu Pratap Singh","","1993-08-20","","","8090439291","","","adeeps143@gmail.com","","","","","","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301190","908429","Ph.D.","Entomology","3000","Latesh Haritwal","Niraj Sharma","Nirmala Sharma ","1996-02-12","","Female","9983908378","836117065463","AAAAA1111A","sharmalatesh27@gmail.com","","","Gandhi Colony, Near Mansa Public Sr. Sec. School, Ward No. 33, Churu, Rajasthan","Gandhi Colony, Near Mansa Public Sr. Sec. School, Ward No. 33, Churu, Rajasthan","UR","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301191","102107","Ph.D.","Law","3000","Manjeet Singh","Naib Singh","Jasbir Kaur ","1986-05-10","Married","Male","9416474447","534328076867","AAAAA1111A","www.ms1986@gmail.com","2301191-4A1rcc89Rhg1dIeqryr3w8pEp-Image-manjeetpicnew.jpg","2301191-TQWWzD0Uu2tq844ZVP7AeQVUb-Sign-Manjitsign.jpg","Near Govt High School Village Mattar District Sirsa-125078","Near Power House, Kalanwali Road VPO Rori Tehsil Kalanwali District Sirsa Haryana-125201","UR","2023-01-29","7","2023-02-06","","","","","Pending","20230130065745QSCi1c0UXc5cGVksqrkiqJHJ5","","");
INSERT INTO basic_detail VALUES("2301192","182273","Ph.D.","Political  Science","3000","Tushar","Sanjeev kumar","","1998-12-28","","","9992032685","","","tusharkapoor863@gmail.com","","","","","","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301193","692293","Ph.D.","Physical Education","3000","Rahul Moudgill","Raj Rattan Sharma","Sunita Sharma ","1984-10-08","Married","Male","7660000040","309215020717","AAAAA1111A","ramneetrahul@gmail.com","","","Sharma Street link road Mansa 151505","Sharma Street link road Mansa 151505","UR","2023-01-29","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301194","988968","Ph.D.","Political  Science","3000","Gurtej singh","Angrej singh","","2023-01-17","","","9417620875","","","gurtejsingh67@yahoo.in","","","","","","2023-01-30","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301195","706224","Ph.D.","Pharmacy","3000","Amit Kumar","Vijay Kumar","Kusum","1990-06-11","Married","Male","9466759944","476984895157","AAAAA1111A","amitmonga11690@gmail.com","2301195-hNmkwSR4FoVKV8LuZAIMFKAeq-Image-amit.jpg","2301195-mhSc4NVRn9ojoC1VjgAuZKpOp-Sign-SIGN(2).jpeg","W.No.12 Indira Nagar Near bus stand, Tohana, Distt. Fatrhanad, Haryana","W.No.12 Indira Nagar Near bus stand, Tohana, Distt. Fatrhanad, Haryana","UR","2023-01-30","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301196","982896","Ph.D.","Education","3000","Sneha Pradhan","Dipen Pradhan","","1999-11-21","","","7908628378","","","ssnayha111@gmail.com","","","","","","2023-01-31","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301197","835775","Ph.D.","Political  Science","3000","Manisha rani","sopat ram","","1994-08-26","","","8083362000","","","manishabror127@gmail.com","","","","","","2023-01-31","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301198","129027","Ph.D.","Political  Science","3000","Vishal","BramhaDeen","","1998-01-26","","","6307862428","","","vkaruna8055@gmail.com","","","","","","2023-01-31","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301199","864904","Ph.D.","Computer Applications","3000","Sonali Kamra","Twinkle kumar kamra","Anju Bala","1995-07-04","Married","Female","9877398987","685348163548","AAAAA1111A","skamra525@gmail.com","2301199-AH4Bp91xuCcWtWVze2olcPUZV-Image-pic.jpg","2301199-fzAmwjcf1bZmPlpg1cpPKQO3j-Sign-signature.jpg","#1885, sector 80,Mohali","#1885, sector 80, Mohali","UR","2023-01-31","7","2023-02-06","2023-04-02","","success","16731153324","Completed","20230204111659VWqs0fJTgOGPEllFKa3BSj1By","","");
INSERT INTO basic_detail VALUES("2301200","614861","Ph.D.","Law","3000","Miss Kulveer Kaur Dhillon","Mr malkeet singh","","1989-12-18","","","7009422193","","","kerachanplin@gmail.com","","","","","","2023-01-31","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301201","185559","Ph.D.","Economics","3000","Mudasir Ahmad Sheergujree","Mohd Ramzan Sheergujree","Jana Bano","1990-03-04","Unmarried","Male","9858451982","201093900397","AAAAA1111A","mudasir1s@yahoo.com","2301201-OhrvQdSVzeCojprmMSz8OnF3c-Image-DocScanner10-Dec-20225-17pm.jpg","2301201-sjyHS27uzxAr5rlfaVVsRUrDe-Sign-DocScanner30-Sep-20228-22pm(1).jpg","Wathoo Keegam Shopian","Wathoo Berthipora
Pincode-192306","OBC","2023-01-31","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301202","637124","Ph.D.","Economics","3000","Navneet Kaur","Karam Singh","Gulshan kaur","1986-01-02","Married","Female","8195064400","243941804362","AAAAA1111A","navneet.economics@gmail.com","2301202-AcB0b2YluLKipo45iz0clwsq9-Image-20230205_214609.jpg","2301202-S88Wmv5AFLNRRPxcsQjP1rT49-Sign-20230205_215736.jpg","#34, mokha colony, near Balaji hospital, ITI chownk, Sunam, distt. Sangrur, Punjab. ","#34,mokha colony, near Balaji hospital, ITI chownk, Sunam, distt. Sangrur, Punjab.","UR","2023-02-01","7","2023-02-06","2023-05-02","","success","16737816992","Completed","20230205103106S8mGeRvDxB6sKW9cbFvVaZ1eT","","");
INSERT INTO basic_detail VALUES("2301203","697872","Ph.D.","Physical Education","3000","NOORKALAM SEKH","BASED SEKH","","1991-06-02","","","9679063622","","","sekhnoorkalam@gmail.com","","","","","","2023-02-01","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301204","393784","Ph.D.","Agronomy","3000","Ajay Kumar","Mahender Singh","","1999-08-29","","","9017310004","","","ajaylakhlan12@gmail.com","2301204-hOGw9GO4ScpmH7bkNSfcnwN8O-Image-ajay.jpg","2301204-nagZbLT16Txhlz4s12xBIqYMJ-Sign-ajay1.jpg","","","","2023-02-01","7","2023-02-06","2023-04-02","","success","16728217609","Completed","20230204040339W77q5kiSJf6JReo85NJ5gh1C4","","");
INSERT INTO basic_detail VALUES("2301205","659018","Ph.D.","Physics","3000","Manu Sachdeva","Pushkar Raj","PINKI","1994-06-17","Married","Female","8295797975","257226897601","AAAAA1111A","mannusachdeva7750@gmail.com","2301205-PtIlGH9Czjuia9Oytela2DSDO-Image-25483A69-A164-46E1-8AC6-B4E0070251D0.jpeg","2301205-tNJQzy8XktmSG6R2hi90U5Ksv-Sign-B0596EA6-9D8D-4C17-8C83-679F8B3D39BA.jpeg","CO HEMANSHU MEHTA H NO 88 BACKSIDE MEHTA DHARAMSHALA MANDI DABWALI SIRSA HARYANA PIN 125104","CO MEHTA ELECTRONICS OPP PUNJAB AND SIND BANK MANDI DABWALI DISTT SIRSA HARYANA PIN 125104","UR","2023-02-01","7","2023-02-06","2023-05-02","","success","16735631245","Completed","20230205051505yFfxxQaNKifDhwLo3FcDGuGDZ","","");
INSERT INTO basic_detail VALUES("2301206","530617","Ph.D.","Physical Education","3000","Shilu kumari","sh jai chand","","1974-01-01","","","9896787935","","","shilusingh2009@gmail.com","","","","","","2023-02-01","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301207","471428","Ph.D.","Economics","3000","Lakhveer kaur","Jasvir singh","","1999-09-10","","","8264245277","","","lakhveerk966@gmail.com","","","","","","2023-02-02","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301208","200009","Ph.D.","Education","3000","AMIT KUMAR KUSHWAHA","RAM MILAN KUSHWAHA","RAMA SATI DEVI","1988-07-01","Married","Male","9336718313","416808081869","AAAAA1111A","amit3334u@gmail.com","2301208-98F7km2ilTtTSJeRKqv8U9EPd-Image-mynewpassportsizephoto.jpg","2301208-ZzKjTMEAd5xt3ftYSbyl7lNBr-Sign-mysign.jpg","VILL- CHERO, POST- CHERO, NEAR- KENDRIYA VIDALAYA CHERO, THANA- SALEMPUR, DIS- DEORIA UTTAR-PRADESH 274509","HOUSE NO.-87 LALITAPURAM COLONY, RAJENDRA NAGAR EAST, GORAKHNATH, DIS- GORAKHPUR, UTTAR-PRADESH 273015","OBC","2023-02-02","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301209","260808","Ph.D.","Computer Applications","3000","Baljit Singh","Santokh Singh","Sarabjit Kaur","1992-01-09","Unmarried","Male","9988181848","919356065762","AAAAA1111A","deol.tony93@gmail.com","","","V.P.O Kalanaur, District Gurdaspur, Tehsils Gurdaspur ","V.P.O Kalanaur, District Gurdaspur, Tehsils Gurdaspur ","UR","2023-02-02","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301210","345450","Ph.D.","Political  Science","3000","ANJANA  DEVI","JAGDISH RAI","SHAKUNTLA DEVI","1996-05-18","Married","Female","6239257399","875829805338","AAAAA1111A","anjana1882@yahoo.com","2301210-hUdV4raftie9pYXs2qI5fhVHR-Image-011-Copy.jpg","2301210-8bkbs3JP7moY7vn6DcRpdKUZm-Sign-007.jpg","VILL KAHNEWALA PO SARDULGARH TEH SARDULGARH DIST MANSA PUNJAB PIN CODE 151507","VILL KAHNEWALA PO SARDULGARH TEH SARDULGARH DIST MANSA PUNJAB PIN CODE 151507","UR","2023-02-02","7","2023-02-06","2023-02-02","","success","16719215386","Completed","20230202232636w0RLBpox3O3JmwcG7p9Pw7UCl","","");
INSERT INTO basic_detail VALUES("2301211","905538","Ph.D.","Punjabi","3000","Kapil dev","Bansi lal","Asha rani","1998-02-28","Unmarried","Male","9468438492","876301151419","AAAAA1111A","kapilkamboj5723@gmail.com","2301211-xQH0uXRmsXssvFFVqMsQS2f8m-Image-P.jpg","2301211-tXjbgGH5ZIt3gYVYM62yHFPuy-Sign-img619.jpg","Dhani mehtab P.O.Kukrawali ","Dhani mehtab P.O.Kukrawali ","BC","2023-02-02","7","2023-02-06","2023-05-02","","success","16734734862","Completed","20230205025328fdLX6Hix0d3YLLLVPQ3eBBapU","","");
INSERT INTO basic_detail VALUES("2301212","843967","Ph.D.","Physics","3000","Nasir Ahmad","Ghulam hassan ganie","","1989-11-15","","","9149479321","","","nasirphysics11@gmail.com","","","","","","2023-02-03","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301213","590551","Ph.D.","Punjabi","3000","PRABHJEET KAUR","BALBIR SINGH","BHUPINDER KAUR","1975-06-01","Married","Female","9876424963","545246956735","AAAAA1111A","kaurprabhjeetdhaliwal@gmail.com","2301213-VSDfSyLNMXbtk0Pk6j7qMJxfg-Image-20230204003121_00001.jpg","2301213-vrbcwckFP6eNZVFEH8oL3zFIj-Sign-prabjit.jpg","VILLAGE BHARUR, POST OFFICE CHATHE SHAKWAN, TEHSIL SUNAM, DISTT. SANGRUR-148028","VILLAGE BHARUR, POST OFFICE CHATHE SHAKWAN, TEHSIL SUNAM, DISTT. SANGRUR-148028","UR","2023-02-03","7","2023-02-06","2023-04-02","","success","16726863964","Completed","20230204010711fzBdtA0Goj3iO44gF56vOXZSh","","");
INSERT INTO basic_detail VALUES("2301214","697935","Ph.D.","Civil Engineering","3000","Vineet Garg","NARINDER PAUL","","1990-06-01","","","9041256373","","","ervineet1990@gmail.com","","","","","","2023-02-03","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301215","854580","Ph.D.","Law","3000","RAKESH KUMAR","Ruldu ram","VIMLA","1993-08-22","Unmarried","Male","9254545104","504888726036","AAAAA1111A","rsaini5104@gmail.com","2301215-XiC0K9sXQqsfH8pGfLMlHB2PP-Image-004_001_001(1).jpg","2301215-f3wpTR0VIuP6nhpwyFTb98sBT-Sign-rakeshsig(1).jpg","CIVIL HOSPITAL ROAD NEAR DHARM KANTA SIWAN KAITHAL","CIVIL HOSPITAL ROAD NEAR DHARM KANTA SIWAN KAITHAL","OBC","2023-02-03","7","2023-02-06","","","","","Pending","20230203072800l3IYeNOxK0vzjbpordLqPukPF","","");
INSERT INTO basic_detail VALUES("2301216","643102","Ph.D.","Plant Breeding and Genetics","3000","Manohar setty","Setty sundarar rao","Setti jammi ","1995-09-20","Unmarried","Male","9490724093","553823743528","AAAAA1111A","manoharsetty3@gmail.com","2301216-RzxnXB7H2WKKcjNys90Jy4YkY-Image-IMG_20220131_232723_copy_1080x1445.jpg","2301216-NvTyTInoGxGnb9NPbZesHN3SF-Sign-IMG_20220120_201948-min_copy_585x330_copy_585x330_1.jpg","S/o Sundar Rao
Kantabansuguda
Arakuvalley
Visakhapatnam
Andhra Pradesh 531149","S/o Sundar Rao
Kantabansuguda
Arakuvalley
Visakhapatnam
Andhra Pradesh 531149","ST","2023-02-03","7","2023-02-06","2023-05-02","","success","16735266386","Completed","20230205041338R21IJ5TX5DCLCxW0WsRCWwvrh","","");
INSERT INTO basic_detail VALUES("2301217","371406","Ph.D.","Physics","3000","NASIR AHMAD GANIE","GHULAM HASSAN GANIE","","1989-11-15","","","9906735605","","","nasirphysics11@gmail.com","2301217-xvymBjBKFtdyr4fZQK4y0xG92-Image-indexRGHRRDG.jpg","2301217-fHlSzAJQ8GPPRjeM2xdqHw8TX-Sign-index.jpg","","","","2023-02-04","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301218","115540","Ph.D.","Physical Education","3000","GURTEJ SIGNH","GURDEEP SIGNH","","1988-01-21","","","9465930050","","","tejbhagitejbhagi@gmail.com","","","","","","2023-02-04","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301219","654246","Ph.D.","Physical Education","3000","GURTEJ SINGH","GURDEEP SIGNH","JASWINDER KAUR","1988-01-21","Married","Male","9465930050","936003679514","AAAAA1111A","tejbhagitejbhagi@gmail.com","","","VILLAGE- BHAGIWANDER , TEHSIL -TALWANDI SABO, DISTT- BATHINDA","VILLAGE- BHAGIWANDER , TEHSIL -TALWANDI SABO, DISTT- BATHINDA","UR","2023-02-04","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301220","827831","Ph.D.","Management","3000","sonali ghai","Satish Ghai","Manisha Ghai","1996-11-17","Married","Female","9023855550","251759771461","AAAAA1111A","sonalighai5555@gmail.com","2301220-GBsdyUQBQrFWlCbVownUOagjA-Image-20kb.jpg","2301220-QDJyMXkhltjHOB9jN3k4m2u8c-Sign-sign.jpg","1885,sector 80, SAS nagar Mohali","1885,sector 80, SAS nagar Mohali","UR","2023-02-04","7","2023-02-06","2023-04-02","","success","16731114323","Completed","20230204110408iCMgW6Tr913nxR1o9hZzYKY4T","","");
INSERT INTO basic_detail VALUES("2301221","123996","Ph.D.","Management","3000","PARDEEP SINGH SIDHU","DARSHAN SINGH SIDHU","JEET KAUR","1978-11-02","Married","Male","9418714903","230627870308","AAAAA1111A","sidhu23ps@gmail.com","","","VPO- POOHLI, DISTRICT-BATHINDA, PUNJAB 151102","H-45/8 UPPER SHANKAR VIHAR, DELHI CANTT, DELHI 110010","UR","2023-02-04","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301222","322348","Ph.D.","Management","3000","madhu","raj kumar bansal","","1977-07-10","","","7888840067","","","madhu13777@gmail.com","","","","","","2023-02-05","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301223","882509","Ph.D.","Management","3000","Philips Joseph","PRABHAT KUMAR JOSEPH","","1965-12-26","","","9209090260","","","philipspjoseph@gmail.com","","","","","","2023-02-05","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301224","192348","Ph.D.","Physical Education","3000","Jaswinder singh","Jaswinder","","1993-02-05","","","9465400086","","","jassirattan@gmail.com","","","","","","2023-02-05","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301225","734091","Ph.D.","Law","3000","HARDEEP KUMAR","TILAK RAJ","SHINDER KAUR","1988-01-06","Married","Male","9417753473","528455630148","AAAAA1111A","hardeep060188@gmail.com","","","#5314, STREET NO.6, NEAR DR. KHURANA EYE HOSPITAL, MALVIYA NAGAR, BATHINDA, PUNJAB, 151001- INDIA","#5314, STREET NO.6, NEAR DR. KHURANA EYE HOSPITAL, MALVIYA NAGAR, BATHINDA, PUNJAB, 151001- INDIA","OBC","2023-02-05","7","2023-02-06","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301226","891959","Ph.D.","Management","0","Padamjeet Singh Mehta","Amarjeet Singh Mehta","NA","1989-10-08","Unmarried","Male","8820000909","340756101963","AAAAA1111A","ratandeep2@gmail.com","2301226-N5Xle3wI8f1k6OoL0YoRZn9pr-Image-sss.jpg","2301226-ioCRPtwmh5cb0HkHqXZC0O31N-Sign-download.png","Mehta Motors Bathinda","Mehta Motors Bathinda","UR","2023-02-07","7","2023-02-07","2023-02-07","","success","0","Completed","00","","");
INSERT INTO basic_detail VALUES("2301227","233676","Ph.D.","Entomology","3000","P Sai Prasad","P Raveendranath","","1998-11-05","","","9704157985","","","saiprasad.entosci@gmail.com","","","","","","2023-03-04","9","2023-03-26","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301228","268952","Ph.D.","Fruit Science","3000","maninder singh","gurmeet singh","baljeet kaur","1997-02-20","Unmarried","Male","9417390177","396260103040","AAAAA1111A","maninderfarmer50@gmail.com","2301228-FNQXkUFdamX4i7txK4LTUGrFi-Image-75179879-E321-4D07-8066-CD7294717E84.jpeg","2301228-yVYCmMnQH5BttE0GhUQYsb8uv-Sign-C3350BF5-74D8-409C-AAD2-321A2AB8054D.jpeg","same","village fatehpur manian wala , tehsil - malout , district- muktsar","UR","2023-03-04","9","2023-03-26","","","","","Pending","20230304221159s3DZlNNIqcaMsj9pOwFHAbInf","","");
INSERT INTO basic_detail VALUES("2301229","263913","Ph.D.","Mathematics","3000","Parveen Kumar","Satnam Chand","","1987-03-20","","","9068754636","","","pkmandal1516@gmail.com","","","","","","2023-03-05","9","2023-03-26","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301230","852160","Ph.D.","Management","3000","SABINOY SARKAR","MADHAB KUMAR SARKAR","","1992-01-10","","","9002243112","","","sabinoysarkar@gmail.com","","","","","","2023-03-05","9","2023-03-26","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301231","731325","Ph.D.","Education","3000","NEERU","SANT SINGH","LEELA WANTI","1976-05-10","Unmarried","Female","6283516319","521940018767","AAAAA1111A","redlotus971@gmail.com","2301231-CJ3r6fH7LJmxtMBY99tAbPH6a-Image-Ms.NeeruSnap001.jpg","2301231-OGk1HrjYvSFwB4InvKPvjAnzD-Sign-neerusign.jpg","HNO.17/336, STREET NO.07, AKALSAR ROAD, OPP.SARDAR NAGAR MOGA","HNO.17/336, STREET NO.07, AKALSAR ROAD, OPP.SARDAR NAGAR MOGA","UR","2023-03-05","9","2023-03-26","2023-05-03","","success","16925943634","Completed","20230305224442S6Yj6A1dC2Ie0zhbdmxhX2Juo","","");
INSERT INTO basic_detail VALUES("2301232","596798","Ph.D.","Political  Science","3000","Somit","Sh Ramniwas","","1994-03-25","","","8684850327","","","mstbro04@gmail.com","","","","","","2023-03-06","9","2023-03-26","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301233","232626","Ph.D.","Management","3000","Bhagya Mohan","B Viswamohanan","Mini Mohanan","1998-03-12","Unmarried","Female","9880786807","536009296601","AAAAA1111A","bhagyamohan903@gmail.com","2301233-t7AktHV17hqKaiaUdGR3TM0jp-Image-Photo.jpg","2301233-hdT6DQFb7xmxTbDnXgxw4BVoc-Sign-Sign.jpg","Vrindavanam, Karamcodu P.O, Chathannoor,Kollam","Vrindavanam, Karamcodu P.O, Chathannoor,Kollam","OBC","2023-03-06","9","2023-03-26","","","","","Pending","20230307001824RQB3fOjfIhuhK5X9ePThqCyXs","","");
INSERT INTO basic_detail VALUES("2301234","969633","Ph.D.","Economics","3000","ROHTASH KUMAR","RAMESHWAR DASS","","1986-03-15","","","9812511470","","","rohtashkurdia@gmail.com","","","","","","2023-03-07","9","2023-03-26","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301235","495425","Ph.D.","Education","3000","MANISHA RAI","NARAYAN RAI","","1983-04-15","","","9416480301","","","jeetpanday123@gmail.com","","","","","","2023-03-07","9","2023-03-26","","","","","Pending","","","");
INSERT INTO basic_detail VALUES("2301236","577451","Ph.D.","Punjabi","3000","Mandeep kaur","Satnam singh","Lakhvir kaur","1986-05-15","Unmarried","Female","8725854279","522503085198","AAAAA1111A","mjhawar86@gmail.com","2301236-fuvfTANtnpwfGsZK9ognefAFD-Image-IMG_20220525_080325(2).jpg","2301236-Dt7cGqcuwoIrNnJoH9hqlRPWc-Sign-download(2).jpg","VPO. Jhawan Dist. Hoshiarpur Teh. Dasuya pincode-144212","Vpo. Jhawan dist.Hoshiarpur teh. Dasuya pincode-144212
","UR","2023-03-07","9","2023-03-26","","","","","Pending","","","");



CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(150) DEFAULT NULL,
  `academic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE KEY `Index 2` (`course_name`),
  KEY `Index 3` (`academic_id`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`academic_id`) REFERENCES `academic_master` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8mb4;

INSERT INTO courses VALUES("1","Matric","1");
INSERT INTO courses VALUES("2","Medical","2");
INSERT INTO courses VALUES("3","Non Medical","2");
INSERT INTO courses VALUES("4","Arts","2");
INSERT INTO courses VALUES("5","Commerce","2");
INSERT INTO courses VALUES("6","PGDM (Post-Graduate Diploma in Management)","5");
INSERT INTO courses VALUES("7","PGDDM (Post-Graduate Diploma in Disaster Management)","5");
INSERT INTO courses VALUES("8","Diploma in Hospital Administration","4");
INSERT INTO courses VALUES("11","Diploma in Petroleum Management","4");
INSERT INTO courses VALUES("13","Diploma in Rural Development","4");
INSERT INTO courses VALUES("15","Diploma in Bioinformatics","4");
INSERT INTO courses VALUES("16","Diploma in Computer Applications","4");
INSERT INTO courses VALUES("17","Diploma in Food Safety and Quality Management","4");
INSERT INTO courses VALUES("18","Diploma in Industrial Safety","4");
INSERT INTO courses VALUES("19","Diploma in Statistics","4");
INSERT INTO courses VALUES("20","Diploma in Mathematics","4");
INSERT INTO courses VALUES("21","Diploma in Management","4");
INSERT INTO courses VALUES("22","Diploma in Human Resource Management","4");
INSERT INTO courses VALUES("23","Diploma in Personnel Management","4");
INSERT INTO courses VALUES("24","Diploma in Marketing","4");
INSERT INTO courses VALUES("25","Diploma in Banking and Finance","4");
INSERT INTO courses VALUES("27","Diploma in Packaging","4");
INSERT INTO courses VALUES("28","Diploma in Computer Application","4");
INSERT INTO courses VALUES("29","Diploma in Taxation","4");
INSERT INTO courses VALUES("30","Diploma in Advertising and Public Relations","4");
INSERT INTO courses VALUES("31","Diploma in Disaster Management","4");
INSERT INTO courses VALUES("32","Diploma in Operations Management","4");
INSERT INTO courses VALUES("33","Diploma in Logistics and Supply Chain Management","4");
INSERT INTO courses VALUES("34","Diploma in Financial Management","4");
INSERT INTO courses VALUES("35","Diploma in Retail Management","4");
INSERT INTO courses VALUES("36","Diploma in International Business","4");
INSERT INTO courses VALUES("37","Diploma in Management (PGDM)","4");
INSERT INTO courses VALUES("38","Certified Financial Planner (CFP)","4");
INSERT INTO courses VALUES("39","Business Accounting and Taxation (BAT)","4");
INSERT INTO courses VALUES("40","Data Visualization","4");
INSERT INTO courses VALUES("41","Diploma in Digital Marketing","4");
INSERT INTO courses VALUES("42","Certificate Programme in Data Science","7");
INSERT INTO courses VALUES("43"," Diploma in Accounting","4");
INSERT INTO courses VALUES("44"," Diploma in Agriculture","4");
INSERT INTO courses VALUES("45"," Diploma in Anesthesia","4");
INSERT INTO courses VALUES("46"," Diploma in Architecture Engineering","4");
INSERT INTO courses VALUES("47"," Diploma in Artificial Intelligence and Data Science","4");
INSERT INTO courses VALUES("48"," Diploma in Artificial Intelligence And Machine Learning","4");
INSERT INTO courses VALUES("49"," Diploma in Automobile Engineering","4");
INSERT INTO courses VALUES("50"," Diploma in Aviation","4");
INSERT INTO courses VALUES("51"," Diploma in Bakery And Confectionery","4");
INSERT INTO courses VALUES("52"," Diploma in Banking and Finance","4");
INSERT INTO courses VALUES("53"," Diploma in Biomedical Engineering","4");
INSERT INTO courses VALUES("54"," Diploma in Biotechnology","4");
INSERT INTO courses VALUES("55"," Diploma in Business Administration","4");
INSERT INTO courses VALUES("56"," Diploma in Business Management","4");
INSERT INTO courses VALUES("57"," Diploma in Chemical Engineering","4");
INSERT INTO courses VALUES("58"," Diploma in Child Health","4");
INSERT INTO courses VALUES("59"," Diploma in Civil Engineering","4");
INSERT INTO courses VALUES("60"," Diploma in Clinical Pathology","4");
INSERT INTO courses VALUES("61"," Diploma in Community Medicine","4");
INSERT INTO courses VALUES("62"," Diploma in Computer Application","4");
INSERT INTO courses VALUES("63"," Diploma in Computer Science Engineering","4");
INSERT INTO courses VALUES("64"," Diploma in Cyber Security","4");
INSERT INTO courses VALUES("65"," Diploma in Electrical Engineering","4");
INSERT INTO courses VALUES("66"," Diploma in Electronics and Communication Engineering","4");
INSERT INTO courses VALUES("67"," Diploma in Library Science","4");
INSERT INTO courses VALUES("68"," Diploma in Nursing","4");
INSERT INTO courses VALUES("69"," Diploma in Nursing Care Assistant","4");
INSERT INTO courses VALUES("70"," Diploma in Occupational Therapy","4");
INSERT INTO courses VALUES("71"," Diploma in Operation Theatre Technician","4");
INSERT INTO courses VALUES("72"," Diploma in Otorhinolaryngology","4");
INSERT INTO courses VALUES("73"," Diploma in Physiotherapy","4");
INSERT INTO courses VALUES("74"," Diploma in Printing Technology","4");
INSERT INTO courses VALUES("75"," Diploma in Rural Health Care","4");
INSERT INTO courses VALUES("76"," Diploma in Textile Chemistry","4");
INSERT INTO courses VALUES("77"," Diploma in Textile Engineering","4");
INSERT INTO courses VALUES("78"," Diploma in X-Ray Technology","4");
INSERT INTO courses VALUES("79"," DiplomaÂ in Food Technology","4");
INSERT INTO courses VALUES("80"," International Diploma Design","4");
INSERT INTO courses VALUES("81"," PG Diploma in Bioinformatics","5");
INSERT INTO courses VALUES("82","Diploma in Hotel Management.","4");
INSERT INTO courses VALUES("83","Diploma in Interior Designing.","4");
INSERT INTO courses VALUES("84","Diploma in Education Technology.","4");
INSERT INTO courses VALUES("85","Diploma in Animation.","4");
INSERT INTO courses VALUES("86","Diploma in Advertising.","4");
INSERT INTO courses VALUES("87","Diploma in Event Management","4");
INSERT INTO courses VALUES("88","Diploma in Biotechnology.","4");
INSERT INTO courses VALUES("89","Diploma in Radiological Technology.","4");
INSERT INTO courses VALUES("90","Diploma in Medical Lab Technology.","4");
INSERT INTO courses VALUES("91","Master of Accountancy","6");
INSERT INTO courses VALUES("92","Master of Advanced Study","6");
INSERT INTO courses VALUES("93","Masters of Agricultural Economics","6");
INSERT INTO courses VALUES("94","Master of Applied Finance","6");
INSERT INTO courses VALUES("95","Master of Applied Science","6");
INSERT INTO courses VALUES("96","Master of Architecture","6");
INSERT INTO courses VALUES("98","Master of Arts in Liberal Studies","6");
INSERT INTO courses VALUES("99","Master of Arts in Special Education","6");
INSERT INTO courses VALUES("100","Master of Arts in Teaching","6");
INSERT INTO courses VALUES("101","Master of Bioethics","6");
INSERT INTO courses VALUES("102","Master of Business Administration","6");
INSERT INTO courses VALUES("103","Master of Business, Entrepreneurship and Technology","6");
INSERT INTO courses VALUES("104","Master of Business","6");
INSERT INTO courses VALUES("105","Master of Business Engineering","6");
INSERT INTO courses VALUES("106","Master of Business Informatics","6");
INSERT INTO courses VALUES("107","Master of Chemistry","6");
INSERT INTO courses VALUES("108","Master of Christian Education","6");
INSERT INTO courses VALUES("109","Master of City Planning","6");
INSERT INTO courses VALUES("110","Master of Commerce","6");
INSERT INTO courses VALUES("111","Master of Computational Finance","6");
INSERT INTO courses VALUES("112","Master of Computer Applications","6");
INSERT INTO courses VALUES("113","Master of Counselling","6");
INSERT INTO courses VALUES("114","Master of Criminal Justice","6");
INSERT INTO courses VALUES("115","Master of Creative Technologies","6");
INSERT INTO courses VALUES("116","Master of Data Science","6");
INSERT INTO courses VALUES("117","Master of Defence Studies","6");
INSERT INTO courses VALUES("118","Master of Design","6");
INSERT INTO courses VALUES("119","Masters of Development Economics","6");
INSERT INTO courses VALUES("120","Master of Divinity","6");
INSERT INTO courses VALUES("121","Master of Economics","6");
INSERT INTO courses VALUES("122","Master of Education","6");
INSERT INTO courses VALUES("123","Master of Engineering","6");
INSERT INTO courses VALUES("124","Master of Engineering Management","6");
INSERT INTO courses VALUES("125","Master of Enterprise","6");
INSERT INTO courses VALUES("126","Master of European Law","6");
INSERT INTO courses VALUES("127","Master of Finance","6");
INSERT INTO courses VALUES("128","Master of Financial Economics","6");
INSERT INTO courses VALUES("129","Master of Financial Engineering","6");
INSERT INTO courses VALUES("130","Master of Financial Mathematics","6");
INSERT INTO courses VALUES("131","Master of Fine Arts","6");
INSERT INTO courses VALUES("132","Master of Health Administration","6");
INSERT INTO courses VALUES("133","Master of Health Economics","6");
INSERT INTO courses VALUES("134","Master of Health Science","6");
INSERT INTO courses VALUES("135","Master of Humanities","6");
INSERT INTO courses VALUES("136","Master of Industrial and Labor Relations","6");
INSERT INTO courses VALUES("137","Master of International Affairs","6");
INSERT INTO courses VALUES("138","Master of International Business","6");
INSERT INTO courses VALUES("139","Masters of International Economics","6");
INSERT INTO courses VALUES("140","Master of International Studies","6");
INSERT INTO courses VALUES("141","Master of Information and Cybersecurity","6");
INSERT INTO courses VALUES("142","Master of Information and Data Science","6");
INSERT INTO courses VALUES("143","Master of Information Management","6");
INSERT INTO courses VALUES("144","Master of Information System Management","6");
INSERT INTO courses VALUES("145","Master of Journalism","6");
INSERT INTO courses VALUES("146","Master of Jurisprudence","6");
INSERT INTO courses VALUES("147","Master of Laws","6");
INSERT INTO courses VALUES("148","Master of Mass Communication","6");
INSERT INTO courses VALUES("149","Master of Studies in Law","6");
INSERT INTO courses VALUES("150","Master of Landscape Architecture","6");
INSERT INTO courses VALUES("151","Master of Letters","6");
INSERT INTO courses VALUES("152","Master of Liberal Arts","6");
INSERT INTO courses VALUES("153","Master of Library and Information Science[1]","6");
INSERT INTO courses VALUES("154","Master of Management","6");
INSERT INTO courses VALUES("155","Master of Management of Innovation","6");
INSERT INTO courses VALUES("156","Master of Marketing","6");
INSERT INTO courses VALUES("157","Master of Mathematical Finance","6");
INSERT INTO courses VALUES("158","Master of Mathematics","6");
INSERT INTO courses VALUES("159","Master of Medical Science","6");
INSERT INTO courses VALUES("160","Master of Medicine","6");
INSERT INTO courses VALUES("161","Masters of Military Art and Science","6");
INSERT INTO courses VALUES("162","Master of Military Operational Art and Science","6");
INSERT INTO courses VALUES("163","Master of Ministry","6");
INSERT INTO courses VALUES("164","Master of Music","6");
INSERT INTO courses VALUES("165","Master of Music Education","6");
INSERT INTO courses VALUES("166","Master of Occupational Behaviour and Development","6");
INSERT INTO courses VALUES("167","Master of Occupational Therapy","6");
INSERT INTO courses VALUES("168","Master of Pharmacy","6");
INSERT INTO courses VALUES("169","Master of Philosophy","6");
INSERT INTO courses VALUES("170","Master of Physician Assistant Studies","6");
INSERT INTO courses VALUES("171","Master of Physics","6");
INSERT INTO courses VALUES("172","Master of Political Science","6");
INSERT INTO courses VALUES("173","Master of Professional Studies","6");
INSERT INTO courses VALUES("174","Master of Psychology","6");
INSERT INTO courses VALUES("175","Master of Public Administration","6");
INSERT INTO courses VALUES("176","Master of Public Affairs","6");
INSERT INTO courses VALUES("177","Master of Public Health","6");
INSERT INTO courses VALUES("178","Master of Public Management","6");
INSERT INTO courses VALUES("179","Master of Public Policy","6");
INSERT INTO courses VALUES("180","Master of Public Relations","6");
INSERT INTO courses VALUES("181","Master of Public Service","6");
INSERT INTO courses VALUES("182","Master of Quantitative Finance","6");
INSERT INTO courses VALUES("183","Master of Rabbinic Studies","6");
INSERT INTO courses VALUES("184","Master of Real Estate Development","6");
INSERT INTO courses VALUES("185","Master of Religious Education","6");
INSERT INTO courses VALUES("186","Master of Research","6");
INSERT INTO courses VALUES("187","Master of Sacred Music","6");
INSERT INTO courses VALUES("188","Master of Sacred Theology","6");
INSERT INTO courses VALUES("189","Master of Science","6");
INSERT INTO courses VALUES("190","Master of Science in Administration","6");
INSERT INTO courses VALUES("191","Master of Science in Archaeology","6");
INSERT INTO courses VALUES("192","Master of Science in Biblical Archaeology","6");
INSERT INTO courses VALUES("193","Master of Science in Bioinformatics","6");
INSERT INTO courses VALUES("194","Master of Science in Computer Science","6");
INSERT INTO courses VALUES("195","Master of Science in Counselling","6");
INSERT INTO courses VALUES("196","Master of Science in Cyber Security","6");
INSERT INTO courses VALUES("197","Master of Science in Engineering","6");
INSERT INTO courses VALUES("198","Master of Science in Development Administration","6");
INSERT INTO courses VALUES("199","Master of Science in Finance","6");
INSERT INTO courses VALUES("200","Master of Science in Health Informatics","6");
INSERT INTO courses VALUES("201","Master of Science in Human Resource Development","6");
INSERT INTO courses VALUES("202","Master of Science in Information Assurance","6");
INSERT INTO courses VALUES("203","Master of Science in Information Systems","6");
INSERT INTO courses VALUES("204","Master of Science in Information Technology","6");
INSERT INTO courses VALUES("205","Master of Science in Leadership","6");
INSERT INTO courses VALUES("206","Master of Science in Management","6");
INSERT INTO courses VALUES("207","Master of Science in Nursing","6");
INSERT INTO courses VALUES("208","Master of Science in Project Management","6");
INSERT INTO courses VALUES("209","Master of Science in Supply Chain Management","6");
INSERT INTO courses VALUES("210","Master of Science in Teaching","6");
INSERT INTO courses VALUES("211","Master of Science in Taxation","6");
INSERT INTO courses VALUES("212","Master of Social Science","6");
INSERT INTO courses VALUES("213","Master of Social Work","6");
INSERT INTO courses VALUES("214","Master of Strategic Studies","6");
INSERT INTO courses VALUES("215","Master of Studies","6");
INSERT INTO courses VALUES("216","Master of Surgery","6");
INSERT INTO courses VALUES("217","Master of Talmudic Law","6");
INSERT INTO courses VALUES("218","Master of Taxation","6");
INSERT INTO courses VALUES("219","Master of Theological Studies","6");
INSERT INTO courses VALUES("220","Master of Technology","6");
INSERT INTO courses VALUES("221","Master of Theology","6");
INSERT INTO courses VALUES("222","Master of Urban Planning","6");
INSERT INTO courses VALUES("223","Master of Veterinary Science","6");
INSERT INTO courses VALUES("224"," Bachelor of Science in Genetic Engineering and Biotechnology","3");
INSERT INTO courses VALUES("225"," Bachelor of Architecture","3");
INSERT INTO courses VALUES("226"," Bachelor of Biochemistry","3");
INSERT INTO courses VALUES("227"," Bachelor of Biomedical Science","3");
INSERT INTO courses VALUES("228"," Bachelor of Business Administration","3");
INSERT INTO courses VALUES("229"," Bachelor of Clinical Science","3");
INSERT INTO courses VALUES("230"," Bachelor of Commerce","3");
INSERT INTO courses VALUES("231"," Bachelor of Computer Applications","3");
INSERT INTO courses VALUES("232"," Bachelor of Community Health","3");
INSERT INTO courses VALUES("233"," Bachelor of Computer Information Systems","3");
INSERT INTO courses VALUES("234"," Bachelor of Science in Construction Technology","3");
INSERT INTO courses VALUES("235"," Bachelor of Criminal Justice","3");
INSERT INTO courses VALUES("236"," Bachelor of Divinity","3");
INSERT INTO courses VALUES("237"," Bachelor of Economics","3");
INSERT INTO courses VALUES("238"," Bachelor of Elementary Education","3");
INSERT INTO courses VALUES("239"," Bachelor of Education","3");
INSERT INTO courses VALUES("240"," Bachelor of Engineering","3");
INSERT INTO courses VALUES("241"," Bachelor of Fine Arts","3");
INSERT INTO courses VALUES("242"," Bachelor of Laws","3");
INSERT INTO courses VALUES("243"," Bachelor of Letters","3");
INSERT INTO courses VALUES("244"," Bachelor of Library & Information Science","3");
INSERT INTO courses VALUES("245"," Bachelor of Information Systems","3");
INSERT INTO courses VALUES("246"," Bachelor of Management","3");
INSERT INTO courses VALUES("247"," Bachelor of Music","3");
INSERT INTO courses VALUES("248"," Bachelor of Pharmacy","3");
INSERT INTO courses VALUES("249"," Bachelor of Philosophy","3");
INSERT INTO courses VALUES("250"," Bachelor of Public Affairs and Policy Management","3");
INSERT INTO courses VALUES("251"," Bachelor of Public Administration","3");
INSERT INTO courses VALUES("252"," Bachelor of Social Work","3");
INSERT INTO courses VALUES("253"," Bachelor of Technology","3");
INSERT INTO courses VALUES("254"," Bachelor of Accountancy","3");
INSERT INTO courses VALUES("255"," Bachelor of Arts in American Studies","3");
INSERT INTO courses VALUES("256"," Bachelor of Arts in American Indian Studies","3");
INSERT INTO courses VALUES("257"," Bachelor of Arts in Applied Psychology","3");
INSERT INTO courses VALUES("258"," Bachelor of Arts in Biology","3");
INSERT INTO courses VALUES("259"," Bachelor of Arts in Anthropology","3");
INSERT INTO courses VALUES("260"," Bachelor of Arts in Child Advocacy","3");
INSERT INTO courses VALUES("261"," Bachelor of Arts in Clinical Psychology","3");
INSERT INTO courses VALUES("262"," Bachelor of Arts in Communication","3");
INSERT INTO courses VALUES("263"," Bachelor of Arts in Forensic Psychology","3");
INSERT INTO courses VALUES("264"," Bachelor of Arts in Organizational Psychology","3");
INSERT INTO courses VALUES("265"," Bachelor of Science in Aerospace Engineering","3");
INSERT INTO courses VALUES("266"," Bachelor of Science in Accountancy","3");
INSERT INTO courses VALUES("267"," Bachelor of Science in Actuarial","3");
INSERT INTO courses VALUES("268"," Bachelor of Science in Agriculture","3");
INSERT INTO courses VALUES("269"," Bachelor of Science in Applied Economics","3");
INSERT INTO courses VALUES("270"," Bachelor of Science in Architecture","3");
INSERT INTO courses VALUES("271"," Bachelor of Science in Architectural Engineering","3");
INSERT INTO courses VALUES("272"," Bachelor of Science in Athletic Training","3");
INSERT INTO courses VALUES("273"," Bachelor of Science in Biology","3");
INSERT INTO courses VALUES("274"," Bachelor of Science in Biomedical Engineering","3");
INSERT INTO courses VALUES("275"," Bachelor of Science in Bible","3");
INSERT INTO courses VALUES("276"," Bachelor of Science in Business Administration","3");
INSERT INTO courses VALUES("277"," Bachelor of Science in Business Administration in Computer Application","3");
INSERT INTO courses VALUES("278"," Bachelor of Science in Business Administration – Economics","3");
INSERT INTO courses VALUES("279"," Bachelor of Science in Business and Technology","3");
INSERT INTO courses VALUES("280"," Bachelor of Science in Chemical Engineering","3");
INSERT INTO courses VALUES("281"," Bachelor of Science in Chemistry","3");
INSERT INTO courses VALUES("282"," Bachelor of Science in Civil Engineering","3");
INSERT INTO courses VALUES("283"," Bachelor of Science in Clinical Laboratory Science","3");
INSERT INTO courses VALUES("284"," Bachelor of Science in Cognitive Science","3");
INSERT INTO courses VALUES("285"," Bachelor of Science in Computer Engineering","3");
INSERT INTO courses VALUES("286"," Bachelor of Science in Computer Science","3");
INSERT INTO courses VALUES("287"," Bachelor of Science in Construction Engineering","3");
INSERT INTO courses VALUES("288"," Bachelor of Science in Construction Management","3");
INSERT INTO courses VALUES("289"," Bachelor of Science in Criminal Justice","3");
INSERT INTO courses VALUES("290"," Bachelor of Science in Criminology","3");
INSERT INTO courses VALUES("291"," Bachelor of Science in Diagnostic Radiography","3");
INSERT INTO courses VALUES("292"," Bachelor of Science in Education","3");
INSERT INTO courses VALUES("293"," Bachelor of Science in Electrical Engineering","3");
INSERT INTO courses VALUES("294"," Bachelor of Science in Engineering Physics","3");
INSERT INTO courses VALUES("295"," Bachelor of Science in Engineering Science","3");
INSERT INTO courses VALUES("296"," Bachelor of Science in Engineering Technology","3");
INSERT INTO courses VALUES("297"," Bachelor of Science in English Literature","3");
INSERT INTO courses VALUES("298"," Bachelor of Science in Environmental Engineering","3");
INSERT INTO courses VALUES("299"," Bachelor of Science in Environmental Science","3");
INSERT INTO courses VALUES("300"," Bachelor of Science in Environmental Studies","3");
INSERT INTO courses VALUES("301"," Bachelor of Arts / Science in Finance","3");
INSERT INTO courses VALUES("302"," Bachelor of Science in Food Science","3");
INSERT INTO courses VALUES("303"," Bachelor of Science in Foreign Service","3");
INSERT INTO courses VALUES("304"," Bachelor of Science in Forensic Science","3");
INSERT INTO courses VALUES("305"," Bachelor of Science in Forestry","3");
INSERT INTO courses VALUES("306"," Bachelor of Science in History","3");
INSERT INTO courses VALUES("307"," Bachelor of Science in Hospitality Management","3");
INSERT INTO courses VALUES("308"," Bachelor of Science in Human Resources Management","3");
INSERT INTO courses VALUES("309"," Bachelor of Science in Industrial Engineering","3");
INSERT INTO courses VALUES("310"," Bachelor of Science in Information Technology","3");
INSERT INTO courses VALUES("311"," Bachelor of Science in Information Systems","3");
INSERT INTO courses VALUES("312"," Bachelor of Science in Integrated Science","3");
INSERT INTO courses VALUES("313"," Bachelor of Science in International Relations","3");
INSERT INTO courses VALUES("314"," Bachelor of Science in Journalism","3");
INSERT INTO courses VALUES("315"," Bachelor of Science in Legal Management","3");
INSERT INTO courses VALUES("316"," Bachelor of Science in Management","3");
INSERT INTO courses VALUES("317"," Bachelor of Science in Manufacturing Engineering","3");
INSERT INTO courses VALUES("318"," Bachelor of Science in Marketing","3");
INSERT INTO courses VALUES("319"," Bachelor of Science in Mathematics","3");
INSERT INTO courses VALUES("320"," Bachelor of Science in Mechanical Engineering","3");
INSERT INTO courses VALUES("321"," Bachelor of Science in Medical Technology","3");
INSERT INTO courses VALUES("322"," Bachelor of Science in Metallurgical Engineering","3");
INSERT INTO courses VALUES("323"," Bachelor of Science in Meteorology","3");
INSERT INTO courses VALUES("324"," Bachelor of Science in Microbiology","3");
INSERT INTO courses VALUES("325"," Bachelor of Science in Mining Engineering","3");
INSERT INTO courses VALUES("326"," Bachelor of Science in Molecular Biology","3");
INSERT INTO courses VALUES("327"," Bachelor of Science in Neuroscience","3");
INSERT INTO courses VALUES("328"," Bachelor of Science in Nursing","3");
INSERT INTO courses VALUES("329"," Bachelor of Science in Nutrition science","3");
INSERT INTO courses VALUES("330"," Bachelor of Science in Software Engineering","3");
INSERT INTO courses VALUES("331"," Bachelor of Science in Petroleum Engineering","3");
INSERT INTO courses VALUES("332"," Bachelor of Science in Podiatry","3");
INSERT INTO courses VALUES("333"," Bachelor of Science in Pharmacology","3");
INSERT INTO courses VALUES("334"," Bachelor of Science in Pharmacy","3");
INSERT INTO courses VALUES("335"," Bachelor of Science in Physical Therapy","3");
INSERT INTO courses VALUES("336"," Bachelor of Science in Physics","3");
INSERT INTO courses VALUES("337"," Bachelor of Science in Plant Science","3");
INSERT INTO courses VALUES("338"," Bachelor of Science in Politics","3");
INSERT INTO courses VALUES("339"," Bachelor of Science in Psychology","3");
INSERT INTO courses VALUES("340"," Bachelor of Science in Public Safety","3");
INSERT INTO courses VALUES("341"," Bachelor of Science in Physiology","3");
INSERT INTO courses VALUES("342"," Bachelor of Science in Quantity Surveying Engineering","3");
INSERT INTO courses VALUES("343"," Bachelor of Science in Radiologic Technology","3");
INSERT INTO courses VALUES("344"," Bachelor of Science in Real-Time Interactive Simulation","3");
INSERT INTO courses VALUES("345"," Bachelor of Science in Religion","3");
INSERT INTO courses VALUES("346"," Bachelor of Science in Respiratory Therapy","3");
INSERT INTO courses VALUES("347"," Bachelor of Science in Retail Management","3");
INSERT INTO courses VALUES("348"," Bachelor of Science in Risk Management and Insurance","3");
INSERT INTO courses VALUES("349"," Bachelor of Science in Science Education","3");
INSERT INTO courses VALUES("350"," Bachelor of Science in Sports Management","3");
INSERT INTO courses VALUES("351"," Bachelor of Science in Systems Engineering","3");
INSERT INTO courses VALUES("352"," Bachelor of Secondary Education","3");
INSERT INTO courses VALUES("353"," Bachelor of Physical Education","3");
INSERT INTO courses VALUES("354"," Bachelor of Music in Jazz Studies","3");
INSERT INTO courses VALUES("355"," Bachelor of Music in Composition","3");
INSERT INTO courses VALUES("356"," Bachelor of Music in Performance","3");
INSERT INTO courses VALUES("357"," Bachelor of Music in Theory","3");
INSERT INTO courses VALUES("358"," Bachelor of Music in Music Education","3");
INSERT INTO courses VALUES("359"," Bachelor of Science in Veterinary Technology","3");
INSERT INTO courses VALUES("360"," Bachelor of Science in military and strategic studies","3");
INSERT INTO courses VALUES("361","Master in Physical Education","6");



CREATE TABLE `discipline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discipline` varchar(500) NOT NULL,
  `course` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL,
  `fee` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO discipline VALUES("3","Computer Applications","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("4","Punjabi","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("5","Political  Science","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("6","Economics","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("7","Mathematics","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("8","Physics","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("9","Civil Engineering","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("10","Plant Pathology","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("11","Agronomy ","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("12","Fruit Science ","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("13","Agriculture Economics","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("14","Physical Education ","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("15","Plant Breeding and Genetics","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("16","Entomology","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("17","Vegetable Science","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("18","Law","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("19","Education ","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("20","Pharmacy","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("23","Religious Studies","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("25","Management","Ph.D.","phd","3000");
INSERT INTO discipline VALUES("26","","","","");
INSERT INTO discipline VALUES("27","","","","");
INSERT INTO discipline VALUES("28","","","","");
INSERT INTO discipline VALUES("29","","","","");
INSERT INTO discipline VALUES("30","","","","");
INSERT INTO discipline VALUES("31","","","","");
INSERT INTO discipline VALUES("32","","","","");
INSERT INTO discipline VALUES("33","","","","");



CREATE TABLE `entrance` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `r_name` varchar(150) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `r_status` varchar(20) DEFAULT NULL,
  `document` varchar(150) DEFAULT NULL,
  `admit_card` int(5) DEFAULT '0',
  `admit_card_type` varchar(50) DEFAULT NULL,
  `exam_date` date DEFAULT NULL,
  `paper_1_start_time` time DEFAULT NULL,
  `paper_1_end_time` time DEFAULT NULL,
  `paper_2_start_time` time DEFAULT NULL,
  `paper_2_end_time` time DEFAULT NULL,
  `report_time_start` time DEFAULT NULL,
  `report_time_end` time DEFAULT NULL,
  `venue_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO entrance VALUES("7","phd","January 2023","2023-01-07","2023-02-05","Inactive","E7Rfz1FGmJMbLBhqk4RbEM3Ul-Ph.DAdvt-Color-Final7Jan23.jpg","1","Online","2023-02-12","10:00:00","11:00:00","12:00:00","13:00:00","09:30:00","10:00:00","https://wheebox.com/gku");
INSERT INTO entrance VALUES("8","msc","August 2022","2023-01-07","2022-12-01","Active","vlAJPBZV6mLLHQ0ttoXv3Uk2D-1655727695phpUonvII.jpeg","0","","","","","","","","","");
INSERT INTO entrance VALUES("9","phd","March 2023","2023-03-03","2023-03-25","Active","sRMMvnQNmeddShuWIb73avfgm-IMG-20230304-WA0014.jpg","0","","","","","","","","","");



CREATE TABLE `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `paper1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paper2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_marks` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO result VALUES("3","2301005","","","","Selected");
INSERT INTO result VALUES("4","2301139","","","","Selected");
INSERT INTO result VALUES("5","2301143","","","","Selected");
INSERT INTO result VALUES("6","2301147","","","","Not Qualified");
INSERT INTO result VALUES("7","2301150","","","","Selected");
INSERT INTO result VALUES("8","2301152","","","","Selected");
INSERT INTO result VALUES("9","2301155","","","","Selected");
INSERT INTO result VALUES("10","2301156","","","","Selected");
INSERT INTO result VALUES("11","2301161","","","","Selected");
INSERT INTO result VALUES("12","2301162","","","","Selected");
INSERT INTO result VALUES("13","2301165","","","","Selected");
INSERT INTO result VALUES("14","2301167","","","","Selected");
INSERT INTO result VALUES("15","2301171","","","","Selected");
INSERT INTO result VALUES("16","2301199","","","","Selected");
INSERT INTO result VALUES("17","2301202","","","","Selected");
INSERT INTO result VALUES("18","2301204","","","","Not Qualified");
INSERT INTO result VALUES("19","2301205","","","","Selected");
INSERT INTO result VALUES("20","2301210","","","","Selected");
INSERT INTO result VALUES("21","2301211","","","","Selected");
INSERT INTO result VALUES("22","2301213","","","","Selected");
INSERT INTO result VALUES("23","2301216","","","","Selected");
INSERT INTO result VALUES("24","2301220","","","","Selected");
INSERT INTO result VALUES("25","2301226","","","","Selected");



CREATE TABLE `tests` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `test_name` varchar(150) DEFAULT NULL,
  `score` varchar(10) DEFAULT NULL,
  `valid_upto` date DEFAULT NULL,
  `test_document` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`test_id`) USING BTREE,
  KEY `FK_phd_basic_detail` (`user_id`) USING BTREE,
  CONSTRAINT `tests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `basic_detail` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

INSERT INTO tests VALUES("3","2301006","ICAR-NET","45","2023-01-12","2301006-MkNnSIBOvOBDWIJb9JfPttf39-Screenshot_20230103-182648.jpg");
INSERT INTO tests VALUES("4","2301156","UGC-NET","52","2035-03-31","2301156-j9x9PvGsuUMLYwqKGE7rl3QBJ-NET-page-001.jpg");
INSERT INTO tests VALUES("5","2301152","UGC-NET","206","2025-01-31","2301152-FJtcKuEnsmJRrtfSCHOmC3nAE-IMG-20230120-WA0005.jpg");
INSERT INTO tests VALUES("6","2301154","UGC-NET","53.33","2070-12-31","2301154-jD5jPm93iuUwRNpddWMk2KqWs-Screenshot_20230122-163507_Drive[1].jpg");
INSERT INTO tests VALUES("7","2301150","UGC-NET","224","2040-12-31","2301150-vD5XidHwN2NjHrlmaMYgGWzML-UGCNETmanpreet.jpg");
INSERT INTO tests VALUES("8","2301162","UGC-NET","10","2012-09-18","2301162-2Uwhvt4fFYltFMaiaoJP3o7iF-DMCUGCNET.jpg");
INSERT INTO tests VALUES("9","2301165","UGC-NET","00","2011-11-30","2301165-WRxWWcEHH48xDxNgCNxuEvWf6-UGCNetP.jpeg");
INSERT INTO tests VALUES("10","2301201","Other","176","2030-02-01","2301201-ZZmFddO2YkNE2wSEp6FKajyYz-IMG_20230102_120901.jpg");
INSERT INTO tests VALUES("11","2301210","UGC-NET","220","2024-11-04","2301210-w1SsqaqcHILyvFxnTtRoG23fa-PB02650416_22J_page-0001.jpg");
INSERT INTO tests VALUES("12","2301205","CSIR-NET","115.125","2054-06-30","2301205-rpjwO0jWjHW0nurb79Co2MLT3-62EBB304-15F1-4301-92EA-878497E88D3B.jpeg");
INSERT INTO tests VALUES("13","2301231","UGC-NET","56","2024-04-11","2301231-AgQOlwUyHdR9i6NXmgBwT2OZK-NET(1).jpg");



CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mep` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `role` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO users VALUES("1","171306","7410","","Shivam","1");
INSERT INTO users VALUES("2","131053","7410","","Amrik Singh","4");
INSERT INTO users VALUES("3","170584","170584","","Research Department","2");
INSERT INTO users VALUES("4","121031","121031","","Dr Sunny Arora","4");

